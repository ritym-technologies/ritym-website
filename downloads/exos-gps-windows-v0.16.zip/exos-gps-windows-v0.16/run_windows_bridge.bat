@echo off
cd /d "%~dp0"
where uv >nul 2>&1
if errorlevel 1 (
  echo The required Python launcher "uv" was not found.
  echo Install uv, then run this file again.
  pause
  exit /b 1
)
uv run --python 3.11 --with-requirements requirements.txt python windows_client\gps_receiver.py
