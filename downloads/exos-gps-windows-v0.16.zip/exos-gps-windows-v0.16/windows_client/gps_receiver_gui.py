import sys
import os
import math
import time
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import serial
import serial.tools.list_ports

class AnimatedGpsApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Exos GPS Bridge - Dual Mode Suite")
        self.root.geometry("720x640")
        self.root.resizable(True, True)

        self.serial_port = None
        self.is_connected = False
        self.radar_angle = 0
        self.current_lat = None
        self.current_lon = None

        self.setup_ui()
        self.start_radar_animation()

    def setup_ui(self):
        style = ttk.Style()
        style.theme_use('clam')

        # Top Header
        header_frame = ttk.Frame(self.root, padding=12)
        header_frame.pack(fill=tk.X)

        title = ttk.Label(header_frame, text="🛰️ Exos GPS Bridge", font=("Segoe UI", 16, "bold"))
        title.pack(anchor=tk.W)

        subtitle = ttk.Label(header_frame, text="Transmitter & Receiver Multi-Platform Telemetry Suite", font=("Segoe UI", 9))
        subtitle.pack(anchor=tk.W)

        # Tabbed Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=8)

        # Tab 1: Receiver Mode
        self.receiver_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.receiver_tab, text=" 📥 Receiver Mode ")

        # Tab 2: Transmitter Mode
        self.transmitter_tab = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.transmitter_tab, text=" 📡 Transmitter Mode ")

        self.setup_receiver_tab()
        self.setup_transmitter_tab()

    def setup_receiver_tab(self):
        # Connection Settings Frame
        conn_frame = ttk.LabelFrame(self.receiver_tab, text=" Connection Settings ", padding=10)
        conn_frame.pack(fill=tk.X, pady=5)

        ttk.Label(conn_frame, text="COM Port:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.com_combo = ttk.Combobox(conn_frame, state="readonly", width=25)
        self.com_combo.grid(row=0, column=1, padx=5)

        self.btn_refresh = ttk.Button(conn_frame, text="🔄 Refresh", command=self.refresh_com_ports)
        self.btn_refresh.grid(row=0, column=2, padx=5)

        ttk.Label(conn_frame, text="Baud Rate:").grid(row=0, column=3, sticky=tk.W, padx=5)
        self.baud_combo = ttk.Combobox(conn_frame, values=["9600", "19200", "38400", "115200"], width=8)
        self.baud_combo.current(0)
        self.baud_combo.grid(row=0, column=4, padx=5)

        self.btn_connect = ttk.Button(conn_frame, text="Connect", width=14, command=self.toggle_connection)
        self.btn_connect.grid(row=1, column=0, columnspan=5, pady=8)

        # Main Body: Radar & Telemetry Split
        body_frame = ttk.Frame(self.receiver_tab)
        body_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        # Radar Canvas Widget
        radar_frame = ttk.LabelFrame(body_frame, text=" Live Satellite Radar ", padding=5)
        radar_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        self.radar_canvas = tk.Canvas(radar_frame, width=220, height=220, bg="#0A0E17", highlightthickness=0)
        self.radar_canvas.pack(fill=tk.BOTH, expand=True)

        # Telemetry Data Cards
        tele_frame = ttk.LabelFrame(body_frame, text=" Telemetry Data ", padding=10)
        tele_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        self.lbl_status = ttk.Label(tele_frame, text="Status: Disconnected 🔴", font=("Segoe UI", 10, "bold"), foreground="#C62828")
        self.lbl_status.pack(anchor=tk.W, pady=2)

        self.lbl_lat = ttk.Label(tele_frame, text="Latitude: --", font=("Segoe UI", 10))
        self.lbl_lat.pack(anchor=tk.W, pady=2)

        self.lbl_lon = ttk.Label(tele_frame, text="Longitude: --", font=("Segoe UI", 10))
        self.lbl_lon.pack(anchor=tk.W, pady=2)

        self.lbl_speed = ttk.Label(tele_frame, text="Speed: --", font=("Segoe UI", 10))
        self.lbl_speed.pack(anchor=tk.W, pady=2)

        self.lbl_sats = ttk.Label(tele_frame, text="Satellites: 🛰️ --", font=("Segoe UI", 10))
        self.lbl_sats.pack(anchor=tk.W, pady=2)

        self.lbl_alt = ttk.Label(tele_frame, text="Altitude: --", font=("Segoe UI", 10))
        self.lbl_alt.pack(anchor=tk.W, pady=2)

        self.btn_maps = ttk.Button(tele_frame, text="🗺️ Open in Google Maps", state=tk.DISABLED, command=self.open_maps)
        self.btn_maps.pack(anchor=tk.W, pady=8)

        # Console Log
        log_frame = ttk.LabelFrame(self.receiver_tab, text=" Live NMEA Stream Log ", padding=5)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.log_area = scrolledtext.ScrolledText(log_frame, height=6, font=("Consolas", 9), bg="#1E1E1E", fg="#00FF66")
        self.log_area.pack(fill=tk.BOTH, expand=True)

        self.refresh_com_ports()

    def setup_transmitter_tab(self):
        tx_frame = ttk.LabelFrame(self.transmitter_tab, text=" Desktop Broadcast / Relay ", padding=15)
        tx_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(tx_frame, text="📡 Transmitter Relay Configuration", font=("Segoe UI", 12, "bold")).pack(anchor=tk.W, pady=5)
        ttk.Label(tx_frame, text="Forward NMEA stream from laptop serial port to network / TCP socket server.").pack(anchor=tk.W, pady=2)

        ttk.Separator(tx_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=10)

        self.tx_canvas = tk.Canvas(tx_frame, width=200, height=150, bg="#0A0E17", highlightthickness=0)
        self.tx_canvas.pack(pady=10)

        self.lbl_tx_status = ttk.Label(tx_frame, text="Transmitter Relay: Ready 🟢", font=("Segoe UI", 11, "bold"))
        self.lbl_tx_status.pack(pady=5)

    def start_radar_animation(self):
        def animate():
            if self.radar_canvas.winfo_exists():
                self.draw_radar()
                self.radar_angle = (self.radar_angle + 4) % 360
            self.root.after(50, animate)

        animate()

    def draw_radar(self):
        c = self.radar_canvas
        c.delete("all")

        w = c.winfo_width() or 220
        h = c.winfo_height() or 220
        cx, cy = w / 2, h / 2
        r = min(w, h) / 2 - 10

        # Concentric Radar Rings
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline="#00E5FF", width=1)
        c.create_oval(cx - r*0.66, cy - r*0.66, cx + r*0.66, cy + r*0.66, outline="#00838F", width=1)
        c.create_oval(cx - r*0.33, cy - r*0.33, cx + r*0.33, cy + r*0.33, outline="#006064", width=1)

        # Crosshairs
        c.create_line(cx - r, cy, cx + r, cy, fill="#006064")
        c.create_line(cx, cy - r, cx, cy + r, fill="#006064")

        # Rotating Radar Line
        rad = math.radians(self.radar_angle)
        lx = cx + r * math.cos(rad)
        ly = cy + r * math.sin(rad)
        c.create_line(cx, cy, lx, ly, fill="#00FF66", width=2)

        # Simulated Satellites
        sats = [(cx + 40, cy - 30), (cx - 50, cy + 20), (cx + 20, cy + 60), (cx - 30, cy - 50)]
        for sx, sy in sats:
            c.create_oval(sx - 4, sy - 4, sx + 4, sy + 4, fill="#FF9800", outline="#FFFFFF")

    def refresh_com_ports(self):
        ports = list(serial.tools.list_ports.comports())
        port_list = [f"{p.device} - {p.description}" for p in ports]
        self.com_combo['values'] = port_list
        if port_list:
            self.com_combo.current(0)

    def toggle_connection(self):
        if not self.is_connected:
            selected = self.com_combo.get()
            if not selected:
                messagebox.showwarning("Warning", "Please select a valid COM port.")
                return
            port_name = selected.split(" - ")[0]
            baud = int(self.baud_combo.get())

            try:
                self.serial_port = serial.Serial(port_name, baudrate=baud, timeout=2)
                self.is_connected = True
                self.btn_connect.config(text="Disconnect")
                self.lbl_status.config(text=f"Status: Connected ({port_name}) 🟢", foreground="#2E7D32")

                threading.Thread(target=self.read_serial_loop, daemon=True).start()
            except Exception as e:
                messagebox.showerror("Error", f"Could not open {port_name}:\n{e}")
        else:
            self.is_connected = False
            if self.serial_port:
                try: self.serial_port.close()
                except Exception: pass
            self.btn_connect.config(text="Connect")
            self.lbl_status.config(text="Status: Disconnected 🔴", foreground="#C62828")

    def read_serial_loop(self):
        while self.is_connected and self.serial_port and self.serial_port.is_open:
            try:
                line = self.serial_port.readline().decode('ascii', errors='ignore')
                if line:
                    self.root.after(0, self.update_log, line)
                    self.parse_nmea(line)
            except Exception:
                break

    def update_log(self, line):
        self.log_area.insert(tk.END, line)
        self.log_area.see(tk.END)

    def parse_nmea(self, line):
        line = line.strip()
        if not line.startswith("$"): return
        parts = line.split("*")[0].split(",")
        if parts[0] in ("$GPRMC", "$GNRMC") and len(parts) >= 9:
            if parts[2] == "A":
                lat = self.convert_nmea(parts[3], parts[4])
                lon = self.convert_nmea(parts[5], parts[6])
                self.current_lat, self.current_lon = lat, lon
                self.root.after(0, lambda: self.lbl_lat.config(text=f"Latitude: {lat:.6f}°"))
                self.root.after(0, lambda: self.lbl_lon.config(text=f"Longitude: {lon:.6f}°"))
                self.root.after(0, lambda: self.btn_maps.config(state=tk.NORMAL))
        elif parts[0] in ("$GPGGA", "$GNGGA") and len(parts) >= 10:
            sats, alt = parts[7], parts[9]
            self.root.after(0, lambda: self.lbl_sats.config(text=f"Satellites: 🛰️ {sats}"))
            self.root.after(0, lambda: self.lbl_alt.config(text=f"Altitude: {alt} m"))

    def convert_nmea(self, val, dir_val):
        if not val or "." not in val: return 0.0
        idx = val.find(".")
        deg = float(val[:idx-2])
        mins = float(val[idx-2:])
        dec = deg + mins/60.0
        return -dec if dir_val in ("S", "W") else dec

    def open_maps(self):
        if self.current_lat and self.current_lon:
            webbrowser.open(f"https://www.google.com/maps?q={self.current_lat},{self.current_lon}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AnimatedGpsApp(root)
    root.mainloop()
