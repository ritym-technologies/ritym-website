/* 🛰️ Exos GPS Station — Complete Geolocation & Network Interceptor */
(function() {
  if (window._exosInjectorActive) return;
  window._exosInjectorActive = true;

  let overrideLat = 40.7128;
  let overrideLon = -74.0060;

  let lastPos = {
    coords: {
      latitude: overrideLat,
      longitude: overrideLon,
      altitude: 50.0,
      accuracy: 3.0,
      altitudeAccuracy: 3.0,
      heading: 0.0,
      speed: 0.0
    },
    timestamp: Date.now()
  };

  async function syncLocation() {
    try {
      const resp = await fetch('http://127.0.0.1:9001/location');
      const data = await resp.json();
      if (typeof data.lat === 'number' && typeof data.lon === 'number' && (data.lat !== 0 || data.lon !== 0)) {
        overrideLat = data.lat;
        overrideLon = data.lon;
        lastPos = {
          coords: {
            latitude: data.lat,
            longitude: data.lon,
            altitude: data.alt || 50.0,
            accuracy: 3.0,
            altitudeAccuracy: 3.0,
            heading: data.bearing || 0.0,
            speed: data.speed || 0.0
          },
          timestamp: Date.now()
        };
      }
    } catch (e) {}
  }

  setInterval(syncLocation, 400);
  syncLocation();

  // 1. Intercept HTML5 Geolocation API
  const mockGeo = {
    getCurrentPosition: function(success, error, options) {
      if (typeof success === 'function') {
        setTimeout(() => success(lastPos), 10);
      }
    },
    watchPosition: function(success, error, options) {
      if (typeof success === 'function') {
        setTimeout(() => success(lastPos), 10);
      }
      return setInterval(() => { if (typeof success === 'function') success(lastPos); }, 400);
    },
    clearWatch: function(id) { clearInterval(id); }
  };

  try {
    Object.defineProperty(navigator, 'geolocation', {
      get: function() { return mockGeo; },
      set: function() {},
      configurable: true
    });
  } catch (e) {}

  try {
    if (window.Navigator && Navigator.prototype) {
      Object.defineProperty(Navigator.prototype, 'geolocation', {
        get: function() { return mockGeo; },
        configurable: true
      });
    }
  } catch (e) {}

  // 2. Intercept fetch() API for Google Geolocation Service (GLS) calls
  try {
    const rawFetch = window.fetch;
    window.fetch = async function(...args) {
      const url = (args[0] && typeof args[0] === 'string') ? args[0] : (args[0] && args[0].url ? args[0].url : '');
      if (typeof url === 'string' && (url.includes('geolocate') || url.includes('geolocation') || url.includes('/maps/preview/p'))) {
        return new Response(JSON.stringify({
          location: { lat: overrideLat, lng: overrideLon },
          accuracy: 3.0
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }
      return rawFetch.apply(this, args);
    };
  } catch(e) {}

  // 3. Intercept XMLHttpRequest for Google Geolocation Service (GLS) calls
  try {
    const rawXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      if (typeof url === 'string' && (url.includes('geolocate') || url.includes('geolocation') || url.includes('/maps/preview/p'))) {
        this.addEventListener('readystatechange', function() {
          if (this.readyState === 4) {
            try {
              Object.defineProperty(this, 'responseText', { value: JSON.stringify({ location: { lat: overrideLat, lng: overrideLon }, accuracy: 3.0 }) });
              Object.defineProperty(this, 'response', { value: JSON.stringify({ location: { lat: overrideLat, lng: overrideLon }, accuracy: 3.0 }) });
              Object.defineProperty(this, 'status', { value: 200 });
            } catch(e) {}
          }
        });
      }
      return rawXHR.apply(this, [method, url, ...rest]);
    };
  } catch(e) {}

  console.log('%c 🛰️ Exos GPS Extension Active: All Frames & Google Maps Geolocation Overridden! ', 'background: #0b0e17; color: #4ade80; font-size: 14px; font-weight: bold; padding: 4px;');
})();