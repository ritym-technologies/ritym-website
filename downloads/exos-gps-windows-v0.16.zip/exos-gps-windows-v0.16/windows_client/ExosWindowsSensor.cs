using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ExosGpsBridge
{
    public class ExosSensorProvider
    {
        public static void Main(string[] args)
        {
            Console.Title = "Exos GPS Solutions - Native Windows Location Provider";
            Console.WriteLine("===================================================");
            Console.WriteLine("  Exos GPS Solutions - Native Windows Sensor Engine");
            Console.WriteLine("===================================================");
            Console.WriteLine("[+] Built-in Windows Location Platform Provider Active.");
            Console.WriteLine("[+] Listening for local NMEA telemetry stream on 127.0.0.1:9003...");

            int port = 9003;
            if (args.Length > 0) int.TryParse(args[0], out port);

            UdpClient listener = new UdpClient(port);
            IPEndPoint groupEP = new IPEndPoint(IPAddress.Loopback, port);

            while (true)
            {
                try
                {
                    byte[] bytes = listener.Receive(ref groupEP);
                    string rawStr = Encoding.UTF8.GetString(bytes);
                    Console.WriteLine("[Telemetry Received]: " + rawStr);
                }
                catch (Exception ex)
                {
                   Console.WriteLine("[-] Engine Notice: " + ex.Message);
                    Thread.Sleep(1000);
                }
            }
        }
    }
}