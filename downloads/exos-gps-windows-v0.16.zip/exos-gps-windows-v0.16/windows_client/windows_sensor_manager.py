import os
import subprocess
import socket
import json

class WindowsSensorManager:
    def __init__(self):
        self.process = None
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.exe_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "ExosWindowsSensor.exe"))
        self.cs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "ExosWindowsSensor.cs"))
        
    def ensure_compiled(self):
        if not os.path.exists(self.exe_path) and os.path.exists(self.cs_path):
            csc = r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
            if os.path.exists(csc):
                cmd = [csc, f"/out:{self.exe_path}", self.cs_path]
                subprocess.run(cmd, capture_output=True)
                
    def start(self):
        self.ensure_compiled()
        if os.path.exists(self.exe_path) and self.process is None:
            try:
                creation_flag = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
                self.process = subprocess.Popen([self.exe_path], creationflags=creation_flag)
            except Exception:
                pass

    def send_location(self, lat, lon, alt=0.0, speed=0.0, bearing=0.0, sats=8):
        if self.process is None:
            self.start()
        try:
            payload = json.dumps({"lat": lat, "lon": lon, "alt": alt,
                                    "speed": speed, "bearing": bearing, "sats": sats})
            self.sock.sendto(payload.encode('utf-8'), ('127.0.0.1', 9003))
        except Exception:
            pass

    def stop(self):
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass
            self.process = None
