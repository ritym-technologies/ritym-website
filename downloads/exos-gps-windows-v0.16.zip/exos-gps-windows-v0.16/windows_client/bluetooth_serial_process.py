"""Cancellable serial-compatible wrapper for Windows Bluetooth SPP ports."""

import os
import subprocess
import sys
import threading

import serial


READY_MARKER = b"@EXOS_PROXY_READY\r\n"
ERROR_PREFIX = b"@EXOS_PROXY_ERROR:"


class BluetoothSerialProcess:
    """Expose the small pyserial interface used by the desktop receiver.

    The actual COM handle belongs to a child process. ``close`` can therefore
    terminate a Windows driver call even when opening the RFCOMM port is stuck.
    """

    def __init__(self, port_name, baudrate=9600, timeout=1.0):
        self.port_name = str(port_name)
        self.baudrate = int(baudrate)
        self.timeout = float(timeout)
        self._process = None
        self._cancelled = False
        self._lock = threading.Lock()

    @property
    def is_open(self):
        process = self._process
        return bool(process is not None and not self._cancelled and process.poll() is None)

    def open(self):
        helper_path = os.path.join(os.path.dirname(__file__), "bluetooth_serial_helper.py")
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        with self._lock:
            if self._cancelled:
                raise serial.SerialException("Bluetooth connection was cancelled")
            self._process = subprocess.Popen(
                [
                    sys.executable,
                    helper_path,
                    self.port_name,
                    str(self.baudrate),
                    str(self.timeout),
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                bufsize=0,
                creationflags=creation_flags,
            )
            process = self._process

        marker = process.stdout.readline()
        if marker != READY_MARKER:
            if marker.startswith(ERROR_PREFIX):
                detail = marker[len(ERROR_PREFIX):].decode("utf-8", errors="replace").strip()
            elif self._cancelled:
                detail = "Bluetooth connection was cancelled"
            else:
                detail = "The phone closed the Bluetooth connection before it became ready"
            self.close()
            raise serial.SerialException(detail)
        return self

    def readline(self):
        if not self.is_open or self._process.stdout is None:
            return b""
        return self._process.stdout.readline()

    def write(self, data):
        if not self.is_open or self._process.stdin is None:
            raise serial.SerialException("Bluetooth connection is closed")
        self._process.stdin.write(data)
        self._process.stdin.flush()
        return len(data)

    def flush(self):
        if self.is_open and self._process.stdin is not None:
            self._process.stdin.flush()

    def close(self):
        with self._lock:
            self._cancelled = True
            process = self._process
        if process is None:
            return
        try:
            if process.stdin is not None:
                process.stdin.close()
        except OSError:
            pass
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2.0)
