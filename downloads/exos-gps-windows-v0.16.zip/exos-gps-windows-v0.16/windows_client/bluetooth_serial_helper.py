"""Isolated Windows Bluetooth SPP serial worker.

Windows can leave a Bluetooth COM open blocked inside the driver. Running that
open in a child process lets the desktop application cancel it reliably without
leaving a poisoned worker thread behind.
"""

import sys
import threading

import serial


READY_MARKER = b"@EXOS_PROXY_READY\r\n"
ERROR_PREFIX = b"@EXOS_PROXY_ERROR:"
RECEIVER_READY = b"EXOS-RECEIVER-READY\r\n"


def _pump_desktop_writes(port):
    while True:
        chunk = sys.stdin.buffer.read(4096)
        if not chunk:
            return
        port.write(chunk)
        port.flush()


def main():
    port_name = sys.argv[1]
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else 9600
    read_timeout = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0

    try:
        port = serial.Serial(
            f"\\\\.\\{port_name}" if not port_name.startswith("\\\\") else port_name,
            baudrate=baud,
            timeout=read_timeout,
            write_timeout=3.0,
        )
        port.write(RECEIVER_READY)
        port.flush()
        sys.stdout.buffer.write(READY_MARKER)
        sys.stdout.buffer.flush()

        threading.Thread(
            target=_pump_desktop_writes,
            args=(port,),
            daemon=True,
        ).start()

        while port.is_open:
            raw = port.readline()
            if raw:
                sys.stdout.buffer.write(raw)
                sys.stdout.buffer.flush()
    except Exception as error:
        message = str(error).replace("\r", " ").replace("\n", " ")
        sys.stdout.buffer.write(
            ERROR_PREFIX + message.encode("utf-8", errors="replace") + b"\r\n"
        )
        sys.stdout.buffer.flush()
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
