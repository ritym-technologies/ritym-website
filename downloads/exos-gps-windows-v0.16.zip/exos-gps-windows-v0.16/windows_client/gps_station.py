import sys
import time
import math
import json
import os
import socket
import threading
import urllib.request
import tkinter as tk
from tkinter import ttk, messagebox
import serial
import serial.tools.list_ports

class GpsStationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🛰️ Exos GPS Station - Telemetry Command Center")
        self.root.geometry("1200x800")
        self.root.minsize(1100, 720)       # prevent controls from being clipped
        self.root.resizable(True, True)
        self.root.configure(bg="#0b0e17")

        # Connection State (Receiver Mode)
        self.serial_inst = None
        self.is_connected = False
        self.read_thread = None
        self.packet_count = 0
        self.is_scanning = False
        self.last_packet_time = 0

        # Transmitter Mode State
        self.app_mode = "RECEIVER"       # or "TRANSMITTER"
        self.tx_serial_inst = None        # local GPS COM port (USB dongle)
        self.tx_read_thread = None
        self.tcp_server_sock = None       # TCP server socket
        self.tcp_clients = []             # connected Android receivers
        self.tcp_server_thread = None
        self.tx_active = False            # True while transmitter loop is running

        # Telemetry State
        self.lat_val = "0.000000°"
        self.lon_val = "0.000000°"
        self.speed_val = "0.0 knots (0.0 km/h)"
        self.bearing_val = "0.0°"
        self.alt_val = "0.0 m (0.0 ft)"
        self.sat_val = "0"
        self.fix_val = "No Fix"
        self.last_sentence = "Awaiting NMEA stream..."

        # UI Setup
        self.setup_styles()
        self.build_gui()

        # Lock window geometry AFTER UI is built — prevents combobox/widget
        # content changes from ever shifting or resizing the window layout.
        self.root.update_idletasks()
        self.root.geometry(self.root.geometry())   # freeze current size

        # Canvas Animation Thread/Loop
        self.stars = []
        self.init_starfield()
        self.anim_tick = 0
        self.geo_polygons = []   # Will hold list of polygon point lists
        self.geo_loaded = False
        self.animate_space()
        # Load world geography in background thread
        threading.Thread(target=self._load_world_geo, daemon=True).start()

        # Auto-scan state
        self._autoscan_running = False
        self._autoscan_cancel = False

        # Auto-refresh COM ports
        self.refresh_com_ports()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Dark theme colors
        style.configure("TFrame", background="#0b0e17")
        style.configure("Card.TFrame", background="#151b28", relief="flat")
        style.configure("TLabel", background="#0b0e17", foreground="#e2e8f0", font=("Segoe UI", 10))
        style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"), foreground="#38bdf8", background="#0b0e17")
        style.configure("SubHeader.TLabel", font=("Segoe UI", 10, "italic"), foreground="#94a3b8", background="#0b0e17")
        style.configure("CardTitle.TLabel", font=("Segoe UI", 10, "bold"), foreground="#94a3b8", background="#151b28")
        style.configure("CardVal.TLabel", font=("Segoe UI", 16, "bold"), foreground="#38bdf8", background="#151b28")
        style.configure("CardSub.TLabel", font=("Segoe UI", 9), foreground="#cbd5e1", background="#151b28")
        
        style.configure("TCombobox", fieldbackground="#1e293b", background="#334155", foreground="#ffffff", arrowcolor="#38bdf8")
        style.map("TCombobox", fieldbackground=[("readonly", "#1e293b")], foreground=[("readonly", "#ffffff")])

        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), background="#0284c7", foreground="#ffffff", borderwidth=0)
        style.map("Accent.TButton", background=[("active", "#0369a1")])
        
        style.configure("Stop.TButton", font=("Segoe UI", 10, "bold"), background="#ef4444", foreground="#ffffff", borderwidth=0)
        style.map("Stop.TButton", background=[("active", "#dc2626")])

    def build_gui(self):
        # Main Layout: Top Control Header, Middle Space Canvas & Telemetry, Bottom NMEA Stream
        
        # 1. TOP HEADER FRAME
        top_frame = ttk.Frame(self.root, padding=(20, 12, 20, 8))
        top_frame.pack(fill="x")

        title_box = ttk.Frame(top_frame)
        title_box.pack(side="left")

        # ── Premium Space-Tech Title (NASA / Mission-Control style) ──────────
        title_canvas = tk.Canvas(title_box, width=660, height=52,
                                 bg="#0b0e17", highlightthickness=0)
        title_canvas.pack(anchor="w")

        # Satellite icon — restored
        title_canvas.create_text(6, 22, anchor="w", text="🛰️",
                                 font=("Segoe UI Emoji", 22), fill="#38bdf8")

        # Exact spaced title: E  X  O  S    G  P  S    S  T  A  T  I  O  N
        # 2 spaces between each letter, 4 spaces between word groups
        # Courier New Bold 22pt — monospace NASA mission-control display font
        full_title = "E  X  O  S    G  P  S    S  T  A  T  I  O  N"
        x_start  = 48
        char_gap = 13   # px per character slot (fits all 44 chars in 660px canvas)

        for i, ch in enumerate(full_title):
            cx = x_start + i * char_gap
            if ch == " ":
                continue   # spaces are positional only — skip drawing
            # Glow shadow layer (2px offset, dark cyan depth)
            title_canvas.create_text(cx + 2, 24, anchor="w", text=ch,
                                     font=("Courier New", 22, "bold"),
                                     fill="#0c4a6e")
            # EXOS (indices 0-9) → ice-white  |  GPS STATION (indices ≥14) → sky-blue
            letter_color = "#e0f2fe" if i < 10 else "#7dd3fc"
            title_canvas.create_text(cx, 22, anchor="w", text=ch,
                                     font=("Courier New", 22, "bold"),
                                     fill=letter_color)

        # Sub-label — company line
        title_canvas.create_text(50, 42, anchor="w",
                                 text="RiTym Technologies  ·  RiTym.com  ·  Exos GPS Solutions",
                                 font=("Segoe UI", 8),
                                 fill="#475569")

        # ── ROW 2: Mode + Port Controls (grid layout — locked, no reflow) ────────
        # grid is used instead of pack so that column widths are pinned and
        # never shift when combobox values or text content changes.
        ctrl_bar = tk.Frame(self.root, bg="#0b0e17", height=40)
        ctrl_bar.pack(fill="x", padx=16, pady=(2, 4))
        ctrl_bar.pack_propagate(False)   # lock frame height — content cannot push it

        # Column definitions: label | combo_mode | spacer | label | combo_ports | btn_autoscan | btn_connect
        col_weights = [0, 0, 0, 0, 0, 0, 0]   # no elastic columns
        for c, (minw) in enumerate([120, 200, 20, 80, 310, 180, 150]):
            ctrl_bar.columnconfigure(c, minsize=minw, weight=0)
        # The last empty column absorbs any remaining space
        ctrl_bar.columnconfigure(7, weight=1)

        tk.Label(ctrl_bar, text="Station Mode:", bg="#0b0e17", fg="#e2e8f0",
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 4))

        self.combo_mode = ttk.Combobox(
            ctrl_bar,
            values=["\U0001f4bb RECEIVER MODE", "\U0001f4e1 TRANSMITTER MODE"],
            width=18, state="readonly")
        self.combo_mode.current(0)
        self.combo_mode.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.combo_mode.bind("<<ComboboxSelected>>", self.on_mode_changed)

        tk.Label(ctrl_bar, text="COM Port:", bg="#0b0e17", fg="#e2e8f0",
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=3, sticky="w", padx=(0, 4))

        # Fixed width — long port names are truncated inside the box, no reflow
        self.combo_ports = ttk.Combobox(ctrl_bar, width=36, state="readonly")
        self.combo_ports.grid(row=0, column=4, sticky="w", padx=(0, 8))

        self.btn_autoscan = ttk.Button(
            ctrl_bar, text="\U0001f50d Auto-Scan Bluetooth",
            command=self.auto_scan_bluetooth)
        self.btn_autoscan.grid(row=0, column=5, sticky="w", padx=(0, 8))

        self.btn_connect = ttk.Button(
            ctrl_bar, text="Connect Station",
            style="Accent.TButton", command=self.toggle_connection)
        self.btn_connect.grid(row=0, column=6, sticky="w")

        # Hardware Sensor Banner / Prerequisite Note
        hw_banner = ttk.Frame(self.root, padding=(20, 2, 20, 6))
        hw_banner.pack(fill="x")
        self.lbl_hw_status = ttk.Label(
            hw_banner,
            text="\u26a1 Hardware Check & Prerequisite: Ensure transmitting unit is Bluetooth-paired with this PC before connecting Receiver Mode.",
            font=("Segoe UI", 10, "bold"),
            foreground="#fbbf24",
            background="#0b0e17"
        )
        self.lbl_hw_status.pack(anchor="w")

        # 2. MAIN CONTENT SPLIT (LEFT: CANVAS SPACE, RIGHT: TELEMETRY DASHBOARD)
        mid_frame = ttk.Frame(self.root, padding=(20, 10, 20, 10))
        mid_frame.pack(fill="both", expand=True)

        # Space Visualizer Canvas (Left)
        canvas_frame = ttk.Frame(mid_frame, style="Card.TFrame")
        canvas_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.canvas = tk.Canvas(canvas_frame, bg="#070a12", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        # Telemetry Dashboard Grid (Right) — width locked, never reflows
        dash_frame = tk.Frame(mid_frame, width=420, bg="#0b0e17")
        dash_frame.pack(side="right", fill="y")
        dash_frame.pack_propagate(False)   # lock at 420px — content never expands it

        # Device Status Card — fixed-height container (140px ensures no text chopping)
        self.card_status = ttk.Frame(dash_frame, style="Card.TFrame", padding=15)
        self.card_status.pack(fill="x", pady=(0, 10))
        self.card_status.pack_propagate(False)   # children cannot push height
        self.card_status.configure(height=140)

        ttk.Label(self.card_status, text="STATION CONNECTION STATUS",
                  style="CardTitle.TLabel").place(x=0, y=0)

        # Status text — fixed width + wraplength so no reflow regardless of message length
        self.lbl_status_text = ttk.Label(
            self.card_status,
            text="\U0001f534 DISCONNECTED",
            font=("Segoe UI", 11, "bold"),
            foreground="#f87171",
            background="#151b28",
            wraplength=370,          # wrap before hitting card edge
            justify="left",
            anchor="w",
            width=42                 # fixed character width — short msgs don't shrink it
        )
        self.lbl_status_text.place(x=0, y=22)

        self.lbl_device_info = ttk.Label(
            self.card_status,
            text="Connected Device: None\nPackets Received: 0",
            style="CardSub.TLabel",
            wraplength=370,
            justify="left",
            anchor="w",
            width=48
        )
        self.lbl_device_info.place(x=0, y=65)

        # Telemetry Cards Grid
        grid_frame = ttk.Frame(dash_frame)
        grid_frame.pack(fill="both", expand=True)

        # Card 1: Coordinates
        c1 = ttk.Frame(grid_frame, style="Card.TFrame", padding=12)
        c1.grid(row=0, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        ttk.Label(c1, text="📍 POSITION (LATITUDE / LONGITUDE)", style="CardTitle.TLabel").pack(anchor="w")
        self.lbl_latlon = ttk.Label(c1, text="0.000000° N , 0.000000° E", style="CardVal.TLabel")
        self.lbl_latlon.pack(anchor="w", pady=(4, 0))

        # Card 2: Satellites & Fix
        c2 = ttk.Frame(grid_frame, style="Card.TFrame", padding=12)
        c2.grid(row=1, column=0, sticky="nsew", padx=(0, 5), pady=(0, 10))
        ttk.Label(c2, text="🛰️ SATELLITES IN FIX", style="CardTitle.TLabel").pack(anchor="w")
        self.lbl_sats = ttk.Label(c2, text="0 Satellites", style="CardVal.TLabel")
        self.lbl_sats.pack(anchor="w", pady=(4, 0))
        self.lbl_fix = ttk.Label(c2, text="Quality: Searching...", style="CardSub.TLabel")
        self.lbl_fix.pack(anchor="w")

        # Card 3: Speed & Bearing
        c3 = ttk.Frame(grid_frame, style="Card.TFrame", padding=12)
        c3.grid(row=1, column=1, sticky="nsew", padx=(5, 0), pady=(0, 10))
        ttk.Label(c3, text="⚡ SPEED & HEADING", style="CardTitle.TLabel").pack(anchor="w")
        self.lbl_speed = ttk.Label(c3, text="0.0 knots", style="CardVal.TLabel")
        self.lbl_speed.pack(anchor="w", pady=(4, 0))
        self.lbl_bearing = ttk.Label(c3, text="Heading: 0.0°", style="CardSub.TLabel")
        self.lbl_bearing.pack(anchor="w")

        # Card 4: Altitude
        c4 = ttk.Frame(grid_frame, style="Card.TFrame", padding=12)
        c4.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        ttk.Label(c4, text="🏔️ ALTITUDE", style="CardTitle.TLabel").pack(anchor="w")
        self.lbl_alt = ttk.Label(c4, text="0.0 m (0.0 ft)", style="CardVal.TLabel")
        self.lbl_alt.pack(anchor="w", pady=(4, 0))

        grid_frame.columnconfigure(0, weight=1)
        grid_frame.columnconfigure(1, weight=1)

        # 3. BOTTOM NMEA STREAM LOG
        bottom_frame = ttk.Frame(self.root, padding=(20, 0, 20, 15))
        bottom_frame.pack(fill="x")

        ttk.Label(bottom_frame, text="📡 LIVE NMEA 0183 SIGNAL TELEMETRY LOG", font=("Segoe UI", 9, "bold"), foreground="#94a3b8").pack(anchor="w", pady=(0, 4))
        
        self.txt_log = tk.Text(bottom_frame, height=5, bg="#070a12", fg="#38bdf8", insertbackground="#38bdf8",
                               font=("Consolas", 9), relief="flat", highlightthickness=1, highlightbackground="#1e293b")
        self.txt_log.pack(fill="x")
        self.txt_log.insert("end", "System Initialized. Connect to Samsung Galaxy S24 FE Bluetooth COM Port to start receiving orbital telemetry...\n")

        # 4. COPYRIGHT & COMPANY FOOTER BAR
        footer_frame = ttk.Frame(self.root, padding=(20, 6, 20, 10))
        footer_frame.pack(fill="x")
        ttk.Label(footer_frame, text="© 2026 RiTym Technologies • RiTym.com • Exos GPS Solutions • All Rights Reserved", font=("Segoe UI", 8), foreground="#64748b").pack(side="right")

    def init_starfield(self):
        import random
        self.stars = []
        for _ in range(120):
            x = random.randint(10, 800)
            y = random.randint(10, 600)
            r = random.uniform(0.6, 2.4)
            self.stars.append((x, y, r, random.uniform(0.1, 1.0)))

    def _load_world_geo(self):
        """Download and cache Natural Earth 110m countries GeoJSON. Runs in background thread."""
        cache_path = os.path.join(os.path.dirname(__file__), "world_110m.geojson")

        # Try to load from cache first
        if os.path.exists(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    geo_data = json.load(f)
                self._parse_geo(geo_data)
                return
            except Exception:
                pass  # Cache corrupt, re-download

        # Download Natural Earth 110m countries (hosted on GitHub/naturalearthdata)
        url = "https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "ExosGPSStation/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw = resp.read().decode("utf-8")
            geo_data = json.loads(raw)
            # Cache it
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(geo_data, f)
            self._parse_geo(geo_data)
        except Exception as e:
            # Fall back silently - canvas will show ocean only
            print(f"[GEO] Could not load world map data: {e}")

    def _parse_geo(self, geo_data):
        """Parse GeoJSON FeatureCollection into flat list of (lat, lon) polygon rings."""
        polygons = []
        for feature in geo_data.get("features", []):
            geom = feature.get("geometry", {})
            g_type = geom.get("type", "")
            coords_list = geom.get("coordinates", [])

            if g_type == "Polygon":
                for ring in coords_list:
                    # GeoJSON coords are [lon, lat]
                    pts = [(c[1], c[0]) for c in ring if len(c) >= 2]
                    if len(pts) >= 4:
                        polygons.append(pts)

            elif g_type == "MultiPolygon":
                for poly in coords_list:
                    for ring in poly:
                        pts = [(c[1], c[0]) for c in ring if len(c) >= 2]
                        if len(pts) >= 4:
                            polygons.append(pts)

        self.geo_polygons = polygons
        self.geo_loaded = True

    def auto_scan_bluetooth(self):
        """Start sequential port probing in a background thread."""
        if self._autoscan_running:
            return  # Already scanning
        if self.is_connected:
            messagebox.showinfo("Auto-Scan", "Already connected. Disconnect first to run auto-scan.")
            return

        ports = list(serial.tools.list_ports.comports())
        if not ports:
            messagebox.showinfo("Auto-Scan", "No COM ports found.\nPlease pair your phone via Windows Bluetooth settings.")
            return

        # Sort: Bluetooth-tagged ports first, USB Modem ports last
        def port_score(p):
            if "BTHENUM" in p.hwid.upper() or "Bluetooth" in p.description:
                return 0
            if "Modem" in p.description:
                return 2
            return 1
        ports.sort(key=port_score)

        # Switch scan button to "Cancel"
        self._autoscan_cancel = False
        self._autoscan_running = True
        self.btn_autoscan.config(text="⛔ Cancel Scan", command=self._cancel_autoscan)
        self.btn_connect.config(state="disabled")

        self.txt_log.insert("end", f"\n[AUTO-SCAN] Starting sequential probe of {len(ports)} COM port(s) (10 s timeout each)...\n")
        self.txt_log.see("end")

        threading.Thread(
            target=self._run_port_scan,
            args=(ports,),
            daemon=True
        ).start()

    def _cancel_autoscan(self):
        self._autoscan_cancel = True
        self.root.after(0, self._autoscan_status, "⛔ Scan cancelled by user.", "#f87171")

    def _autoscan_status(self, msg, color="#38bdf8"):
        """Thread-safe status update to log and status bar."""
        self.lbl_status_text.config(text=msg, foreground=color)
        self.txt_log.insert("end", f"[AUTO-SCAN] {msg}\n")
        self.txt_log.see("end")

    def _autoscan_done(self):
        """Restore UI after scan finishes (called on main thread)."""
        self._autoscan_running = False
        self.btn_autoscan.config(text="🔍 Auto-Scan Bluetooth", command=self.auto_scan_bluetooth)
        self.btn_connect.config(state="normal")

    def _run_port_scan(self, ports):
        """Background thread: probe EVERY port for up to 15 s looking for live NMEA data.
        A transient read error never skips a port — we keep trying until the deadline."""
        found = False
        total = len(ports)

        for idx, port_info in enumerate(ports):
            if self._autoscan_cancel:
                break

            port_name = port_info.device
            self.root.after(0, self._autoscan_status,
                            f"🔍 [{idx+1}/{total}] Probing {port_name} ({port_info.description})…",
                            "#fbbf24")

            # ── Open port ──────────────────────────────────────────────────────
            ser = None
            try:
                ser = serial.Serial(port_name, baudrate=9600, timeout=1)
            except Exception as e:
                self.root.after(0, self._autoscan_status,
                                f"⚠️  [{idx+1}/{total}] {port_name} — Cannot open ({type(e).__name__}). Skipping.",
                                "#64748b")
                continue   # <-- always try the next port

            # ── Bluetooth SPP settle delay (gives phone time to accept connection) ──
            # Without this, the first few readline() calls return empty before data flows
            time.sleep(1.5)

            # ── Read for up to 15 seconds looking for a valid NMEA sentence ───
            PROBE_TIMEOUT = 15.0
            deadline = time.time() + PROBE_TIMEOUT
            nmea_found = False
            last_tick_log = 0  # avoid flooding the log with countdown every second

            while time.time() < deadline and not self._autoscan_cancel:
                remaining = int(deadline - time.time())
                if remaining != last_tick_log:
                    last_tick_log = remaining
                    self.root.after(0, self._autoscan_status,
                                    f"📡 [{idx+1}/{total}] {port_name} — listening… ({remaining}s remaining)",
                                    "#fbbf24")

                try:
                    line = ser.readline().decode("ascii", errors="ignore").strip()
                    if line.startswith("$") and len(line) > 6:
                        nmea_found = True
                        break
                    # Empty line (timeout hit on readline) — just loop again
                except serial.SerialException:
                    # Port disconnected mid-probe — stop probing this port
                    break
                except Exception:
                    # Any other transient error — keep trying until deadline
                    time.sleep(0.05)
                    continue

            # ── Close port regardless of result ───────────────────────────────
            try:
                ser.close()
            except Exception:
                pass

            if self._autoscan_cancel:
                break

            if nmea_found:
                found = True
                def _do_connect(pn=port_name):
                    for i, val in enumerate(self.combo_ports["values"]):
                        if pn in val:
                            self.combo_ports.current(i)
                            break
                    self._autoscan_done()
                    self._autoscan_status(f"✅ GPS Station found on {pn}! Connecting…", "#4ade80")
                    self.connect()
                self.root.after(0, _do_connect)
                return  # success — exit scan

            else:
                self.root.after(0, self._autoscan_status,
                                f"⏱  [{idx+1}/{total}] {port_name} — No GPS data in 15 s. Moving to next port…",
                                "#64748b")

        # ── All ports exhausted ────────────────────────────────────────────────
        if not found and not self._autoscan_cancel:
            self.root.after(0, self._autoscan_status,
                            f"❌ No GPS Station found on any of the {total} port(s). "
                            "Ensure phone Bluetooth is paired & Exos GPS is transmitting.",
                            "#f87171")

        self.root.after(0, self._autoscan_done)


    def get_country_name(self, lat: float, lon: float) -> str:
        if 8.0 <= lat <= 37.0 and 68.0 <= lon <= 97.0:
            return "India 🇮🇳"
        elif 24.0 <= lat <= 49.0 and -125.0 <= lon <= -66.0:
            return "United States 🇺🇸"
        elif 50.0 <= lat <= 60.0 and -8.0 <= lon <= 2.0:
            return "United Kingdom 🇬🇧"
        elif 47.0 <= lat <= 55.0 and 5.0 <= lon <= 15.0:
            return "Germany 🇩🇪"
        elif 42.0 <= lat <= 51.0 and -5.0 <= lon <= 8.0:
            return "France 🇫🇷"
        elif 30.0 <= lat <= 45.0 and 129.0 <= lon <= 146.0:
            return "Japan 🇯🇵"
        elif -44.0 <= lat <= -10.0 and 112.0 <= lon <= 154.0:
            return "Australia 🇦🇺"
        elif -33.0 <= lat <= 5.0 and -74.0 <= lon <= -34.0:
            return "Brazil 🇧🇷"
        elif 45.0 <= lat <= 70.0 and -140.0 <= lon <= -60.0:
            return "Canada 🇨🇦"
        elif 35.0 <= lat <= 70.0 and -10.0 <= lon <= 40.0:
            return "Europe 🇪🇺"
        elif 0.0 <= lat <= 70.0 and 40.0 <= lon <= 180.0:
            return "Asia 🌏"
        elif -35.0 <= lat <= 37.0 and -20.0 <= lon <= 52.0:
            return "Africa 🌍"
        else:
            return "Global Waters / International"

    def animate_space(self):
        self.anim_tick += 1
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()

        if w > 50 and h > 50:
            self.canvas.delete("all")

            # ── 1. DEEP SPACE BACKGROUND & TWINKLING STARS ──────────────────────
            for x_ratio, y_ratio, r, brightness in self.stars:
                cx = (x_ratio / 800.0) * w
                cy = (y_ratio / 600.0) * h
                alpha = math.sin(self.anim_tick * 0.07 + brightness * 9) * 0.45 + 0.55
                color = "#ffffff" if alpha > 0.75 else "#93c5fd" if alpha > 0.5 else "#1e293b"
                self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill=color, outline="")

            # ── 2. PARSE REAL-TIME GPS TELEMETRY ────────────────────────────────
            try:
                sat_count_num = int(self.lbl_sats.cget("text").split()[0]) if "Satellites" in self.lbl_sats.cget("text") else 8
            except:
                sat_count_num = 8

            try:
                lat_str, lon_str = self.lbl_latlon.cget("text").split(",")
                fix_lat = float(lat_str.split("°")[0].strip())
                fix_lon = float(lon_str.split("°")[0].strip())
            except:
                fix_lat, fix_lon = 12.9716, 77.5946  # Default: Bangalore, India

            country_name = self.get_country_name(fix_lat, fix_lon)

            # ── 3. EARTH GLOBE SPHERE (CENTERED ON FIX LOCATION) ────────────────
            globe_cx = w / 2.0
            globe_cy = h / 2.0 + 8
            globe_r  = min(w, h) * 0.33

            # Globe is centered on the user's GPS fix — exactly like Google Earth "zoom to location"
            clat = math.radians(fix_lat)
            clon = math.radians(fix_lon)

            # Outer atmosphere glow rings
            for extra, color, wid in [(18, "#0369a1", 2), (8, "#0ea5e9", 1)]:
                self.canvas.create_oval(globe_cx - globe_r - extra, globe_cy - globe_r - extra,
                                        globe_cx + globe_r + extra, globe_cy + globe_r + extra,
                                        fill="", outline=color, width=wid)

            # Deep ocean base — vibrant blue sphere
            self.canvas.create_oval(globe_cx - globe_r, globe_cy - globe_r,
                                    globe_cx + globe_r, globe_cy + globe_r,
                                    fill="#1e40af", outline="#3b82f6", width=2)

            # ── 3a. ORTHOGRAPHIC PROJECTION ENGINE ──────────────────────────────
            def ortho(lat_deg, lon_deg):
                """Project (lat, lon) degrees onto screen (x, y). Returns None if behind globe."""
                la = math.radians(lat_deg)
                lo = math.radians(lon_deg)
                cos_c = (math.sin(clat) * math.sin(la) +
                         math.cos(clat) * math.cos(la) * math.cos(lo - clon))
                if cos_c <= 0.0:
                    return None
                x = globe_cx + globe_r * math.cos(la) * math.sin(lo - clon)
                y = globe_cy - globe_r * (math.cos(clat) * math.sin(la) -
                                          math.sin(clat) * math.cos(la) * math.cos(lo - clon))
                # Clip to globe disc
                if (x - globe_cx)**2 + (y - globe_cy)**2 > (globe_r * 0.99)**2:
                    return None
                return (x, y)

            # ── 3b. GRATICULE GRID (Lat/Lon lines) ─────────────────────────────
            # Latitude parallels
            for lat_deg in range(-80, 90, 20):
                pts = []
                for lon_deg in range(-180, 181, 5):
                    p = ortho(lat_deg, lon_deg)
                    if p:
                        pts.extend(p)
                    elif pts:
                        if len(pts) >= 4:
                            self.canvas.create_line(pts, fill="#1e3a5f", width=1, smooth=True)
                        pts = []
                if len(pts) >= 4:
                    self.canvas.create_line(pts, fill="#1e3a5f", width=1, smooth=True)

            # Longitude meridians
            for lon_deg in range(-180, 180, 20):
                pts = []
                for lat_deg in range(-90, 91, 5):
                    p = ortho(lat_deg, lon_deg)
                    if p:
                        pts.extend(p)
                    elif pts:
                        if len(pts) >= 4:
                            self.canvas.create_line(pts, fill="#1e3a5f", width=1, smooth=True)
                        pts = []
                if len(pts) >= 4:
                    self.canvas.create_line(pts, fill="#1e3a5f", width=1, smooth=True)

            # ── 3c. REAL COUNTRY POLYGONS (Natural Earth 110m GeoJSON) ──────────
            if self.geo_loaded and self.geo_polygons:
                for ring in self.geo_polygons:
                    # Project each vertex; split polygon at visibility boundary
                    segments = []
                    current_seg = []
                    for (p_lat, p_lon) in ring:
                        pt = ortho(p_lat, p_lon)
                        if pt:
                            current_seg.extend([pt[0], pt[1]])
                        else:
                            if len(current_seg) >= 6:
                                segments.append(current_seg)
                            current_seg = []
                    if len(current_seg) >= 6:
                        segments.append(current_seg)

                    for seg in segments:
                        # Fill visible polygon segment
                        self.canvas.create_polygon(seg,
                                                   fill="#2d6a30",     # rich earth green
                                                   outline="#22c55e",  # bright coastline
                                                   width=1)
            else:
                # Loading indicator while GeoJSON downloads
                status = "🌐 Loading world map..." if not self.geo_loaded else "🌐 Globe ready"
                self.canvas.create_text(globe_cx, globe_cy, text=status,
                                        fill="#64748b", font=("Segoe UI", 11, "italic"))

            # (North polar ice cap removed — cleaner globe view)

            # Equator highlight line
            eq_pts = []
            for lo in range(-180, 181, 4):
                p = ortho(0, lo)
                if p:
                    eq_pts.extend(p)
                elif eq_pts:
                    if len(eq_pts) >= 4:
                        self.canvas.create_line(eq_pts, fill="#0369a1", width=1, dash=(4, 4))
                    eq_pts = []
            if len(eq_pts) >= 4:
                self.canvas.create_line(eq_pts, fill="#0369a1", width=1, dash=(4, 4))

            # ── 4. GPS FIX BEACON (Google Earth pin style) ─────────────────────
            tpt = ortho(fix_lat, fix_lon) or (globe_cx, globe_cy)
            tx, ty = tpt

            # Sonar pulse rings
            for pulse_scale in [1.0, 0.6, 0.3]:
                pr = ((self.anim_tick * 2.0 * pulse_scale) % 38)
                alpha_fade = 1.0 - pr / 38.0
                ring_color = "#38bdf8" if alpha_fade > 0.5 else "#0ea5e9"
                self.canvas.create_oval(tx - pr, ty - pr, tx + pr, ty + pr,
                                        outline=ring_color, width=1)

            # Red teardrop pin (Google-Earth style)
            self.canvas.create_oval(tx - 8, ty - 8, tx + 8, ty + 8,
                                    fill="#ef4444", outline="#ffffff", width=2)
            self.canvas.create_oval(tx - 3, ty - 3, tx + 3, ty + 3,
                                    fill="#fde047", outline="")

            # Country label badge
            label = f"📍 {country_name}"
            self.canvas.create_text(tx, ty - 22, text=label,
                                    fill="#4ade80", font=("Segoe UI", 9, "bold"))
            self.canvas.create_text(tx, ty + 20,
                                    text=f"{fix_lat:.4f}°N, {fix_lon:.4f}°E",
                                    fill="#e2e8f0", font=("Segoe UI", 8))

            # ── 5. ORBITAL SATELLITE CONSTELLATION ─────────────────────────────
            num_sats = max(4, min(16, sat_count_num))
            orb_rx = globe_r + 62
            orb_ry = orb_rx * 0.58

            # Orbital ellipse track
            self.canvas.create_oval(globe_cx - orb_rx, globe_cy - orb_ry,
                                    globe_cx + orb_rx, globe_cy + orb_ry,
                                    outline="#1e3a5f", dash=(4, 6), width=1)

            for i in range(num_sats):
                angle = (self.anim_tick * 0.014 + i * (2 * math.pi / num_sats)) % (2 * math.pi)
                sx = globe_cx + math.cos(angle) * orb_rx
                sy = globe_cy + math.sin(angle) * orb_ry

                # Solar panel wings
                self.canvas.create_rectangle(sx - 14, sy - 2, sx - 5, sy + 2,
                                             fill="#0284c7", outline="#38bdf8")
                self.canvas.create_rectangle(sx + 5, sy - 2, sx + 14, sy + 2,
                                             fill="#0284c7", outline="#38bdf8")
                # Satellite body
                self.canvas.create_rectangle(sx - 5, sy - 4, sx + 5, sy + 4,
                                             fill="#1e293b", outline="#94a3b8", width=1)
                # Antenna dish dot
                self.canvas.create_oval(sx - 2, sy - 2, sx + 2, sy + 2,
                                        fill="#ffffff", outline="")
                # Label
                self.canvas.create_text(sx, sy - 13, text=f"SAT-{i+1:02d}",
                                        fill="#94a3b8", font=("Segoe UI", 7, "bold"))

                # Laser telemetry beam (animated photon travelling from satellite to fix)
                if self.is_connected:
                    prog = (self.anim_tick * 0.055 + i * 0.15) % 1.0
                    bx = sx + (tx - sx) * prog
                    by = sy + (ty - sy) * prog
                    self.canvas.create_line(sx, sy, tx, ty,
                                            fill="#0284c7", dash=(2, 5), width=1)
                    self.canvas.create_oval(bx - 3, by - 3, bx + 3, by + 3,
                                            fill="#38bdf8", outline="#bae6fd")

            # ── 6. HUD CAPTION ─────────────────────────────────────────────────
            geo_status = f"🌐 EARTH TELEMETRY RADAR  •  {num_sats} SATS LOCKED  •  {country_name}"
            if not self.geo_loaded:
                geo_status = "🌐 Downloading world map… (first run only)"
            self.canvas.create_text(globe_cx, globe_cy + globe_r + 26,
                                    text=geo_status,
                                    fill="#cbd5e1", font=("Segoe UI", 9, "bold"))

        self.root.after(40, self.animate_space)


    def on_mode_changed(self, event=None):
        mode = self.combo_mode.get()
        is_tx = "TRANSMITTER" in mode

        # Stop any active connection before switching
        if self.is_connected:
            self.disconnect()
        if self.tx_active:
            self.stop_transmitter_mode()

        if is_tx:
            self.app_mode = "TRANSMITTER"
            self.lbl_hw_status.config(
                text="📡 TRANSMITTER MODE: Auto-scanning COM ports for USB GPS dongle...",
                foreground="#38bdf8")
            self.btn_connect.config(text="Start Transmitting", style="Accent.TButton")
            # Update port label hint
            self.btn_autoscan.config(text="🔍 Scan for GPS Dongle")
        else:
            self.app_mode = "RECEIVER"
            self.lbl_hw_status.config(
                text="⚡ Hardware Check: No Built-in GPS Sensor on this PC. Receiver Mode is active.",
                foreground="#fbbf24")
            self.btn_connect.config(text="Connect Station", style="Accent.TButton")
            self.btn_autoscan.config(text="🔍 Auto-Scan Bluetooth")

    def refresh_com_ports(self, auto_select_best=False):
        ports = list(serial.tools.list_ports.comports())
        port_list = []
        best_index = 0
        best_score = -100
        curr_selection = self.combo_ports.get().split(" - ")[0].strip() if self.combo_ports.get() else ""

        for idx, p in enumerate(ports):
            score = 0
            desc = p.description

            # Smart scoring for Bluetooth SPP vs USB Modem
            if "Exos" in desc or "GPS Bridge" in desc:
                score += 50
            elif "Standard Serial over Bluetooth" in desc or "BTHENUM" in p.hwid.upper() or "Bluetooth" in desc:
                score += 30
            
            if "Modem" in desc or "USB VID" in p.hwid.upper():
                score -= 30

            display_name = f"{p.device} - {desc}"
            if score > 0:
                display_name += "  [⚡ RECOMMENDED]"

            port_list.append(display_name)

            if score > best_score:
                best_score = score
                best_index = idx

        self.combo_ports["values"] = port_list
        if port_list:
            match_idx = -1
            if curr_selection:
                for i, item in enumerate(port_list):
                    if item.startswith(curr_selection):
                        match_idx = i
                        break
            if match_idx >= 0:
                self.combo_ports.current(match_idx)
            elif auto_select_best or not self.combo_ports.get():
                self.combo_ports.current(best_index)

    def auto_scan_bluetooth(self):
        """Loops through all available COM ports starting from the next port in the list.
        If the last port was selected, loops back to the first port (index 0).
        Probes each port for 15 seconds listening for NMEA streams."""
        if self.is_connected:
            messagebox.showinfo("Already Connected", "Receiver is already connected to a COM port.")
            return
        if self.is_scanning:
            return

        self.refresh_com_ports(auto_select_best=False)
        port_values = list(self.combo_ports["values"])
        if not port_values:
            messagebox.showwarning("No COM Ports", "No COM ports found.\n\nPlease pair your transmitter phone via Windows Bluetooth Settings first.")
            return

        total_ports = len(port_values)
        curr_idx = self.combo_ports.current()
        if curr_idx < 0:
            curr_idx = 0
        # Calculate starting index: next port in list, wrapping around to 0 if at the end
        start_idx = (curr_idx + 1) % total_ports

        self.is_scanning = True
        self.btn_autoscan.config(state="disabled", text="⏳ Auto-Scanning...")

        scan_thread = threading.Thread(target=self._auto_scan_worker, args=(start_idx, total_ports), daemon=True)
        scan_thread.start()

    def _auto_scan_worker(self, start_idx, total_ports):
        found_port = None
        port_values = list(self.combo_ports["values"])

        for offset in range(total_ports):
            if not self.is_scanning:
                break
            
            idx = (start_idx + offset) % total_ports
            item_str = port_values[idx]
            port_name = item_str.split(" - ")[0].strip()

            self.root.after(0, lambda i=idx, p=port_name, cur=offset+1, tot=total_ports: (
                self.combo_ports.current(i),
                self.lbl_status_text.config(
                    text=f"🔍 [{cur}/{tot}] Probing {p} (15s timeout)...",
                    foreground="#fbbf24"
                ),
                self.log_message(f"[AUTO-SCAN] Probing port {p} ({cur}/{tot})...\n")
            ))

            try:
                s = serial.Serial(port_name, baudrate=9600, timeout=1.0)
                start_time = time.time()
                while time.time() - start_time < 15.0 and self.is_scanning:
                    line = s.readline().decode('ascii', errors='ignore').strip()
                    if line.startswith("$GP") or line.startswith("$GN") or (line.startswith("$") and len(line) > 6):
                        found_port = idx
                        break
                s.close()
            except Exception:
                pass

            if found_port is not None:
                break

        def finish_scan():
            self.is_scanning = False
            self.btn_autoscan.config(state="normal", text="🔍 Auto-Scan Bluetooth")
            if found_port is not None:
                self.combo_ports.current(found_port)
                self.log_message(f"[AUTO-SCAN] ✅ GPS Station transmitter detected on {port_values[found_port]}!\n")
                self.connect()
            else:
                self.lbl_status_text.config(
                    text="🔴 No GPS Station found on any COM port",
                    foreground="#f87171"
                )
                self.lbl_device_info.config(text="Status: Scan complete — No active GPS stream detected")
                self.log_message("[AUTO-SCAN] Finished scan. No GPS station received on any COM port.\n")

        self.root.after(0, finish_scan)

    def toggle_connection(self):
        if self.app_mode == "TRANSMITTER":
            if self.tx_active:
                self.stop_transmitter_mode()
            else:
                self.start_transmitter_mode()
        else:
            if self.is_connected:
                self.disconnect()
            else:
                self.connect()

    def connect(self):
        selected = self.combo_ports.get()
        if not selected:
            messagebox.showwarning("Port Error", "No COM ports available! Please pair your phone via Bluetooth.")
            return

        port_name = selected.split(" - ")[0].strip()
        try:
            self.serial_inst = serial.Serial(port_name, baudrate=9600, timeout=1.0)
            self.is_connected = True
            self.packet_count = 0
            self.last_packet_time = time.time()
            
            self.btn_connect.config(text="Disconnect Receiver", style="Stop.TButton")
            self.lbl_status_text.config(text=f"🟢 ONLINE & STREAMING ({port_name})", foreground="#4ade80")
            self.lbl_device_info.config(text=f"Connected Device: Exos Station via {port_name}\nPackets Received: 0")

            self.txt_log.insert("end", f"\n[SYSTEM] Connected to {port_name} at 9600 baud. Listening for NMEA satellite streams...\n")
            self.txt_log.see("end")

            self.read_thread = threading.Thread(target=self.listen_serial, daemon=True)
            self.read_thread.start()

        except Exception as e:
            # Auto-fallback suggestion if user clicked wrong port (like USB Modem COM5)
            ports = list(serial.tools.list_ports.comports())
            bluetooth_ports = [p.device for p in ports if "Bluetooth" in p.description or "BTHENUM" in p.hwid.upper()]

            err_msg = f"Could not connect to {port_name}:\n{e}\n\n"
            if bluetooth_ports and port_name not in bluetooth_ports:
                err_msg += f"💡 Tip: '{port_name}' looks like a USB Modem cable port. Would you like to switch to Bluetooth port '{bluetooth_ports[0]}'?"
                if messagebox.askyesno("Wrong Port Selected", err_msg):
                    for i, val in enumerate(self.combo_ports["values"]):
                        if bluetooth_ports[0] in val:
                            self.combo_ports.current(i)
                            self.connect()
                            return
            else:
                messagebox.showerror("Connection Failed", err_msg)

    def disconnect(self):
        self.is_connected = False
        if self.serial_inst and self.serial_inst.is_open:
            try:
                self.serial_inst.close()
            except:
                pass
        self.btn_connect.config(text="Connect Station", style="Accent.TButton")
        self.lbl_status_text.config(text="\U0001f534 DISCONNECTED", foreground="#f87171")
        self.lbl_device_info.config(text="Connected Device: None\nPackets Received: 0")
        self.txt_log.insert("end", "\n[SYSTEM] Station Disconnected.\n")
        self.txt_log.see("end")

    def handle_stream_stoppage(self):
        if not self.is_connected:
            return
        port_name = self.combo_ports.get().split(" - ")[0] if self.combo_ports.get() else ""
        self.lbl_status_text.config(
            text=f"⚠️ TRANSMITTER STOPPED / OFFLINE ({port_name})",
            foreground="#f59e0b"
        )
        self.lbl_sats.config(text="0 Satellites")
        self.lbl_fix.config(text="Fix: Transmitter Paused 🟡")
        self.lbl_device_info.config(
            text=f"Connected Device: Station Idle via {port_name}\nPackets Received: {self.packet_count} (Stream Paused)"
        )
        self.log_message(f"[SYSTEM] Notice: Transmitting device stopped sending NMEA data on {port_name}.\n")

    # ── TRANSMITTER MODE METHODS ──────────────────────────────────────────────

    def start_transmitter_mode(self):
        """Scan COM ports for a USB GPS dongle, read NMEA locally,
        and serve it via TCP port 9000 to Android receivers."""
        selected = self.combo_ports.get()
        if not selected:
            messagebox.showwarning("No Port", "No COM port selected.\nSelect the port your USB GPS dongle is on.")
            return

        port_name = selected.split(" - ")[0].strip()
        try:
            self.tx_serial_inst = serial.Serial(port_name, baudrate=9600, timeout=2)
        except Exception as e:
            messagebox.showerror("GPS Port Error", f"Could not open {port_name}:\n{e}")
            return

        # Start TCP server so Android receivers can connect
        try:
            self.tcp_server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.tcp_server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.tcp_server_sock.bind(("", 9000))
            self.tcp_server_sock.listen(5)
            self.tcp_server_sock.settimeout(1.0)   # allow clean shutdown
        except Exception as e:
            messagebox.showerror("TCP Server Error", f"Could not start TCP server on port 9000:\n{e}")
            self.tx_serial_inst.close()
            return

        self.tx_active = True
        self.tcp_clients = []

        # Get LAN IP for display
        try:
            lan_ip = socket.gethostbyname(socket.gethostname())
        except:
            lan_ip = "<your-PC-IP>"

        self.btn_connect.config(text="Stop Transmitting", style="Stop.TButton")
        self.lbl_status_text.config(
            text=f"\U0001f7e2 TRANSMITTING — GPS on {port_name}",
            foreground="#4ade80")
        self.lbl_device_info.config(
            text=f"TCP Server: {lan_ip}:9000  |  Clients: 0")
        self.txt_log.insert("end",
            f"\n[TRANSMITTER] GPS port: {port_name} | TCP server: {lan_ip}:9000\n"
            f"[TRANSMITTER] Android receivers: go to Settings → connect to {lan_ip}:9000\n")
        self.txt_log.see("end")
        self.lbl_hw_status.config(
            text=f"📡 TRANSMITTING — GPS on {port_name} | TCP Receiver server: {lan_ip}:9000",
            foreground="#4ade80")

        # Background threads
        self.tx_read_thread = threading.Thread(target=self._tx_scan_and_read, daemon=True)
        self.tx_read_thread.start()
        self.tcp_server_thread = threading.Thread(target=self._tcp_server_loop, daemon=True)
        self.tcp_server_thread.start()

    def stop_transmitter_mode(self):
        """Shut down transmitter: close GPS port, TCP server and all clients."""
        self.tx_active = False

        for c in list(self.tcp_clients):
            try: c.close()
            except: pass
        self.tcp_clients.clear()

        if self.tcp_server_sock:
            try: self.tcp_server_sock.close()
            except: pass
            self.tcp_server_sock = None

        if self.tx_serial_inst and self.tx_serial_inst.is_open:
            try: self.tx_serial_inst.close()
            except: pass
            self.tx_serial_inst = None

        self.btn_connect.config(text="Start Transmitting", style="Accent.TButton")
        self.lbl_status_text.config(text="\U0001f534 TRANSMITTER STOPPED", foreground="#f87171")
        self.lbl_device_info.config(text="TCP Server: Offline  |  Clients: 0")
        self.txt_log.insert("end", "\n[TRANSMITTER] Stopped.\n")
        self.txt_log.see("end")
        self.lbl_hw_status.config(
            text="📡 TRANSMITTER MODE: Ready — press Start Transmitting to begin.",
            foreground="#38bdf8")

    def _tx_scan_and_read(self):
        """Background thread: read NMEA from local GPS COM port,
        update UI telemetry, and broadcast to TCP-connected Android receivers."""
        while self.tx_active:
            try:
                raw = self.tx_serial_inst.readline()
                if not raw:
                    continue
                line = raw.decode('ascii', errors='ignore').strip()
                if not line.startswith('$'):
                    continue

                # Update telemetry display (same parser used for receiver mode)
                self.root.after(0, self.process_nmea, line)

                # Broadcast raw NMEA to all connected TCP clients
                payload = (line + "\r\n").encode('ascii', errors='ignore')
                dead = []
                for c in list(self.tcp_clients):
                    try:
                        c.sendall(payload)
                    except:
                        dead.append(c)
                for c in dead:
                    self.tcp_clients.remove(c)
                if dead:
                    n = len(self.tcp_clients)
                    self.root.after(0, lambda n=n: self.lbl_device_info.config(
                        text=f"TCP Server: Online  |  Clients: {n}"))

            except serial.SerialException:
                if self.tx_active:
                    self.root.after(0, self.log_message, "[TRANSMITTER] GPS dongle disconnected!\n")
                break
            except Exception as e:
                if self.tx_active:
                    self.root.after(0, self.log_message, f"[TRANSMITTER] Read error: {e}\n")

    def _tcp_server_loop(self):
        """Background thread: accept incoming TCP connections from Android receivers."""
        while self.tx_active:
            try:
                conn, addr = self.tcp_server_sock.accept()
                self.tcp_clients.append(conn)
                n = len(self.tcp_clients)
                self.root.after(0, lambda n=n, a=addr: (
                    self.lbl_device_info.config(text=f"TCP Server: Online  |  Clients: {n}"),
                    self.log_message(f"[TRANSMITTER] Receiver connected: {a[0]}:{a[1]}\n")
                ))
            except socket.timeout:
                continue    # normal — loop checks tx_active flag
            except Exception:
                break

    def listen_serial(self):
        while self.is_connected and self.serial_inst and self.serial_inst.is_open:
            try:
                line = self.serial_inst.readline().decode('ascii', errors='ignore')
                if line:
                    self.packet_count += 1
                    self.last_packet_time = time.time()
                    self.root.after(0, self.process_nmea, line.strip())
                else:
                    # Serial read timeout (1s) — check if transmitter stopped sending data (>10s)
                    if self.is_connected and (time.time() - self.last_packet_time > 10.0):
                        self.root.after(0, self.handle_stream_stoppage)
            except Exception as e:
                if self.is_connected:
                    self.root.after(0, self.handle_stream_stoppage)
                break

    def process_nmea(self, line: str):
        if not line.startswith("$"):
            return

        self.log_message(f"{line}\n")

        # Parse checksum
        if "*" in line:
            data, checksum_hex = line.split("*", 1)
            calculated = 0
            for char in data[1:]:
                calculated ^= ord(char)
            if f"{calculated:02X}" != checksum_hex.upper():
                return
        else:
            data = line

        parts = data.split(",")
        sentence_type = parts[0]

        if sentence_type in ("$GPRMC", "$GNRMC") and len(parts) >= 9:
            status = parts[2]
            if status == "A":
                raw_lat, lat_dir = parts[3], parts[4]
                raw_lon, lon_dir = parts[5], parts[6]
                speed_knots = float(parts[7]) if parts[7] else 0.0
                bearing = parts[8] if parts[8] else "0.0"

                lat_deg = self.convert_nmea_to_decimal(raw_lat, lat_dir)
                lon_deg = self.convert_nmea_to_decimal(raw_lon, lon_dir)

                speed_kmh = speed_knots * 1.852

                self.lbl_latlon.config(text=f"{lat_deg:.6f}° {lat_dir} , {lon_deg:.6f}° {lon_dir}")
                self.lbl_speed.config(text=f"{speed_knots:.1f} knots ({speed_kmh:.1f} km/h)")
                self.lbl_bearing.config(text=f"Heading: {bearing}°")

        elif sentence_type in ("$GPGGA", "$GNGGA") and len(parts) >= 10:
            fix_quality = parts[6]
            sat_count = parts[7]
            alt_meters = float(parts[9]) if parts[9] else 0.0
            alt_feet = alt_meters * 3.28084

            fix_str = "GPS 3D Fix 🟢" if fix_quality in ("1", "2") else "Searching Satellites 🟡"
            self.lbl_sats.config(text=f"{sat_count} Satellites")
            self.lbl_fix.config(text=f"Fix: {fix_str}")
            self.lbl_alt.config(text=f"{alt_meters:.1f} m ({alt_feet:.1f} ft)")

        port_name = self.combo_ports.get().split(" - ")[0] if self.combo_ports.get() else ""
        if "TRANSMITTER STOPPED" in self.lbl_status_text.cget("text"):
            self.lbl_status_text.config(text=f"🟢 ONLINE & STREAMING ({port_name})", foreground="#4ade80")
        self.lbl_device_info.config(text=f"Connected Device: Exos Station via {port_name}\nPackets Received: {self.packet_count}")

    def convert_nmea_to_decimal(self, nmea_val: str, direction: str) -> float:
        if not nmea_val:
            return 0.0
        dot_idx = nmea_val.find(".")
        if dot_idx < 0:
            return 0.0
        deg_len = dot_idx - 2
        degrees = float(nmea_val[:deg_len])
        minutes = float(nmea_val[deg_len:])
        decimal = degrees + (minutes / 60.0)
        return decimal

    def log_message(self, text: str):
        self.txt_log.insert("end", text)
        self.txt_log.see("end")

def main():
    root = tk.Tk()
    app = GpsStationApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
