"""Small DNS-SD discovery layer for EXOS GPS emitters.

The parsing and formatting helpers are deliberately independent of zeroconf so
they can be unit tested (and the receiver can still run) when the optional
network-discovery dependency is unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass
import ipaddress
import socket
import threading
from typing import Iterable, Mapping, Optional

try:
    from .exos_ble import parse_canonical_identity, short_id_from_canonical
except ImportError:  # Support direct execution from windows_client.
    from exos_ble import parse_canonical_identity, short_id_from_canonical


SERVICE_TYPE = "_exos-gps._tcp.local."

try:
    from zeroconf import IPVersion, ServiceBrowser, ServiceListener, Zeroconf
except ImportError:  # Discovery is optional; fixed/manual sources still work.
    IPVersion = ServiceBrowser = ServiceListener = Zeroconf = None


@dataclass(frozen=True)
class DiscoveredEmitter:
    device_id: str
    service_name: str
    hostname: str
    ip_address: str
    port: int
    model: str = ""
    protocol_version: str = ""
    data_format: str = ""
    firmware_version: str = ""
    http_port: Optional[int] = None
    auth_mode: str = ""
    short_id: str = ""


def decode_txt(properties: Mapping[object, object]) -> dict[str, str]:
    """Decode zeroconf TXT properties into normalized UTF-8 strings."""
    decoded: dict[str, str] = {}
    for raw_key, raw_value in (properties or {}).items():
        key = _decode_text(raw_key).strip().lower()
        if key:
            decoded[key] = _decode_text(raw_value).strip()
    return decoded


def _decode_text(value: object) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if value is None:
        return ""
    return str(value)


def choose_ipv4(addresses: Iterable[object]) -> Optional[str]:
    """Return a deterministic, usable IPv4 address from ServiceInfo data.

    When an ESP advertises both AP and station interfaces, prefer its station
    address over the well-known setup AP address (192.168.4.1).
    """
    candidates: set[str] = set()
    for raw in addresses or ():
        try:
            if isinstance(raw, bytes):
                if len(raw) != 4:
                    continue
                text = socket.inet_ntop(socket.AF_INET, raw)
            else:
                text = str(raw).split("%", 1)[0]
            address = ipaddress.ip_address(text)
            if address.version == 4 and not address.is_unspecified and not address.is_loopback:
                candidates.add(str(address))
        except (OSError, ValueError):
            continue

    if not candidates:
        return None
    return sorted(candidates, key=lambda value: (value == "192.168.4.1", ipaddress.ip_address(value)))[0]


def emitter_from_service_info(info: object) -> Optional[DiscoveredEmitter]:
    """Convert a zeroconf ServiceInfo-like object into an emitter record."""
    properties = decode_txt(getattr(info, "properties", {}))
    ip_address = choose_ipv4(getattr(info, "addresses", ()))
    port = _parse_port(getattr(info, "port", None))
    if not ip_address or port is None:
        return None

    service_name = _service_instance_name(getattr(info, "name", ""))
    hostname = _decode_text(getattr(info, "server", "")).rstrip(".")
    device_id = properties.get("id", "").strip() or hostname or service_name
    if not device_id:
        return None

    short_id = (properties.get("shortid", "") or "").strip().upper()
    canonical_id = parse_canonical_identity(device_id)
    canonical_short_id = short_id_from_canonical(canonical_id) if canonical_id else None
    if canonical_short_id and short_id and short_id != canonical_short_id:
        # Do not publish an internally inconsistent identity into the source
        # picker or use it later to constrain a BLE authentication attempt.
        return None

    return DiscoveredEmitter(
        device_id=device_id,
        service_name=service_name or device_id,
        hostname=hostname,
        ip_address=ip_address,
        port=port,
        model=properties.get("model", ""),
        protocol_version=properties.get("proto", ""),
        data_format=properties.get("format", ""),
        firmware_version=properties.get("fw", ""),
        http_port=_parse_port(properties.get("http")),
        auth_mode=properties.get("auth", ""),
        short_id=canonical_short_id or short_id,
    )


def _parse_port(value: object) -> Optional[int]:
    try:
        port = int(value)
    except (TypeError, ValueError):
        return None
    return port if 1 <= port <= 65535 else None


def _service_instance_name(name: object) -> str:
    text = _decode_text(name).rstrip(".")
    suffix = SERVICE_TYPE.rstrip(".")
    if text.lower().endswith("." + suffix.lower()):
        text = text[: -(len(suffix) + 1)]
    return text


def emitter_display_name(emitter: DiscoveredEmitter) -> str:
    """Return the shared EXOS-GPS five-character product label."""
    suffix = (
        short_id_from_canonical(emitter.device_id)
        or short_id_from_canonical(emitter.short_id)
        or "GPS"
    )
    return f"EXOS-GPS-{suffix}"


def format_discovered_source(emitter: DiscoveredEmitter) -> str:
    """Format a discovered device for the existing TCP source parser."""
    return (
        f"WiFi TCP - {emitter.ip_address}:{emitter.port} "
        f"[{emitter_display_name(emitter)} \u2014 Wi-Fi]"
    )


def deduplicate_emitters(emitters: Iterable[DiscoveredEmitter]) -> list[DiscoveredEmitter]:
    """Merge duplicate observations by stable device ID.

    Prefer a station-network address to the fixed setup-AP address, then use a
    lexical tie-breaker so results do not depend on callback ordering.
    """
    by_id: dict[str, DiscoveredEmitter] = {}
    for emitter in emitters:
        canonical_id = parse_canonical_identity(emitter.device_id)
        key = (canonical_id or emitter.device_id).casefold()
        current = by_id.get(key)
        if current is None or _emitter_rank(emitter) < _emitter_rank(current):
            by_id[key] = emitter
    return sorted(by_id.values(), key=lambda item: (emitter_display_name(item), item.ip_address, item.port))


def _emitter_rank(emitter: DiscoveredEmitter) -> tuple[bool, ipaddress.IPv4Address, int]:
    return (
        emitter.ip_address == "192.168.4.1",
        ipaddress.ip_address(emitter.ip_address),
        emitter.port,
    )


def discovery_available() -> bool:
    return Zeroconf is not None


class _OneShotListener:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._emitters: list[DiscoveredEmitter] = []

    def add_service(self, zeroconf: object, service_type: str, name: str) -> None:
        self._resolve(zeroconf, service_type, name)

    def update_service(self, zeroconf: object, service_type: str, name: str) -> None:
        self._resolve(zeroconf, service_type, name)

    def remove_service(self, zeroconf: object, service_type: str, name: str) -> None:
        return

    def _resolve(self, zeroconf: object, service_type: str, name: str) -> None:
        try:
            info = zeroconf.get_service_info(service_type, name, timeout=1200)
            emitter = emitter_from_service_info(info) if info is not None else None
            if emitter is not None:
                with self._lock:
                    self._emitters.append(emitter)
        except Exception:
            # A malformed or disappearing advertisement must not stop a scan.
            return

    def snapshot(self) -> list[DiscoveredEmitter]:
        with self._lock:
            return deduplicate_emitters(tuple(self._emitters))


def discover_emitters(timeout_seconds: float = 2.5) -> list[DiscoveredEmitter]:
    """Perform a bounded IPv4 DNS-SD browse.

    This function intentionally blocks for the requested scan window and is
    designed to be called from a worker thread, never from Tk's main thread.
    """
    if not discovery_available():
        return []

    listener = _OneShotListener()
    zeroconf = Zeroconf(ip_version=IPVersion.V4Only)
    browser = None
    try:
        browser = ServiceBrowser(zeroconf, SERVICE_TYPE, listener)
        threading.Event().wait(max(0.1, float(timeout_seconds)))
        return listener.snapshot()
    finally:
        if browser is not None:
            cancel = getattr(browser, "cancel", None)
            if callable(cancel):
                cancel()
        zeroconf.close()
