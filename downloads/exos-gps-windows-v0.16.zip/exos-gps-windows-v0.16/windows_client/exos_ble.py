"""BLE discovery and Nordic-UART NMEA transport for EXOS-GPS.

The pure identity, advertisement, source-formatting and framing helpers remain
usable when Bleak is not installed. Actual scanning/streaming is optional so
Wi-Fi TCP and USB/serial operation continue to work unchanged.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import hashlib
import re
import threading
from typing import Callable, Iterable, Optional


NUS_SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
NUS_RX_CHARACTERISTIC_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
NUS_TX_CHARACTERISTIC_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
NUS_IDENTITY_CHARACTERISTIC_UUID = "6e400004-b5a3-f393-e0a9-e50e24dcca9e"
CROCKFORD_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
IDENTITY_DOMAIN = b"EXOS-GPS-ID-v1"
CANONICAL_ID_PATTERN = re.compile(r"^EXOS-([0-9A-F]{12})$", re.IGNORECASE)
RAW_MAC_PATTERN = re.compile(
    r"^(?:[0-9A-F]{12}|(?:[0-9A-F]{2}[:-]){5}[0-9A-F]{2})$",
    re.IGNORECASE,
)
BLE_NAME_PATTERN = re.compile(
    r"^EXOS-GPS-([0-9A-HJKMNP-TV-Z]{5})-BT$", re.IGNORECASE
)
BLE_SOURCE_LABEL_PATTERN = re.compile(
    r"^EXOS-GPS-([0-9A-HJKMNP-TV-Z]{5})\s+(?:\u2014|-)\s+Bluetooth$",
    re.IGNORECASE,
)
BLE_SOURCE_PREFIX = "BLE GATT - "

try:
    from bleak import BleakClient, BleakScanner
except ImportError:  # BLE is optional; Wi-Fi and USB sources remain available.
    BleakClient = BleakScanner = None

try:
    from bleak.backends.winrt.util import assert_mta
    from winrt.windows.devices.bluetooth import BluetoothLEDevice
    from winrt.windows.devices.enumeration import (
        DeviceInformation,
        DevicePairingKinds,
        DevicePairingProtectionLevel,
        DevicePairingResultStatus,
    )
except (ImportError, OSError):  # Non-Windows hosts can still test pure helpers.
    assert_mta = None
    BluetoothLEDevice = DeviceInformation = None
    DevicePairingKinds = DevicePairingProtectionLevel = None
    DevicePairingResultStatus = None


PAIRING_CANCELLED_MESSAGE = "Bluetooth pairing cancelled by user."
WINDOWS_PAIRING_TIMEOUT_SECONDS = 35.0


class BlePairingError(RuntimeError):
    """Raised when Windows cannot complete authenticated custom pairing."""


class BlePairingCancelled(BlePairingError):
    """Raised when the user closes the PIN prompt without pairing."""


@dataclass(frozen=True)
class BleEmitter:
    device_id: str
    name: str
    address: str
    rssi: int = -127
    service_uuids: tuple[str, ...] = ()
    # Preserve Bleak's scan result. Passing this object to BleakClient avoids
    # an implicit second scan during connect, which is particularly important
    # on Windows when pairing several transports are visible at once.
    ble_device: object = field(default=None, compare=False, repr=False)


@dataclass(frozen=True)
class BleEndpoint:
    address: str
    device_id: str


@dataclass(frozen=True)
class WindowsPairingOutcome:
    already_paired: bool


def factory_short_id(mac: bytes) -> str:
    """Derive the shared five-character product ID from six factory MAC bytes."""
    if len(mac) != 6:
        raise ValueError("Factory MAC must contain exactly 6 bytes")
    digest = hashlib.sha256(IDENTITY_DOMAIN + bytes(mac)).digest()
    first_25_bits = int.from_bytes(digest[:4], "big") >> 7
    return "".join(
        CROCKFORD_ALPHABET[(first_25_bits >> shift) & 0x1F]
        for shift in (20, 15, 10, 5, 0)
    )


def parse_canonical_identity(value: object) -> Optional[str]:
    """Validate and normalize the protected ``EXOS-<12HEX>`` identity."""
    match = CANONICAL_ID_PATTERN.fullmatch(str(value or "").strip())
    return f"EXOS-{match.group(1).upper()}" if match else None


def short_id_from_canonical(value: object) -> Optional[str]:
    """Return the shared short ID from a short ID, canonical ID, or raw MAC."""
    text = str(value or "").strip().upper()
    if len(text) == 5 and all(ch in CROCKFORD_ALPHABET for ch in text):
        return text

    canonical = parse_canonical_identity(text)
    mac_text = canonical[5:] if canonical else text
    if not canonical and not RAW_MAC_PATTERN.fullmatch(mac_text):
        return None
    try:
        return factory_short_id(bytes.fromhex(mac_text.replace(":", "").replace("-", "")))
    except ValueError:
        return None


def parse_ble_name(name: object) -> Optional[str]:
    match = BLE_NAME_PATTERN.fullmatch(str(name or "").strip())
    return match.group(1).upper() if match else None


def validate_pairing_pin(value: object) -> str:
    """Validate the dashboard PIN without normalizing, logging, or persisting it."""
    pin = value if isinstance(value, str) else ""
    if not re.fullmatch(r"[0-9]{6}", pin):
        raise ValueError("Bluetooth pairing PIN must contain exactly six digits")
    return pin


def _native_bluetooth_address(address: str, ble_device: object = None) -> int:
    """Resolve the WinRT 48-bit Bluetooth address from a Bleak observation."""
    details = getattr(ble_device, "details", None)
    raw_advertisement = getattr(details, "adv", None)
    if raw_advertisement is None:
        raw_advertisement = getattr(details, "scan", None)
    native_address = getattr(raw_advertisement, "bluetooth_address", None)
    if native_address is not None:
        value = int(native_address)
        if 0 <= value <= 0xFFFFFFFFFFFF:
            return value

    compact = str(address or "").replace(":", "").replace("-", "")
    if not re.fullmatch(r"[0-9A-Fa-f]{12}", compact):
        raise BlePairingError("Windows Bluetooth address is unavailable or invalid")
    return int(compact, 16)


async def ensure_windows_pin_pairing(
    address: str,
    ble_device: object,
    pin_provider: Callable[[], Optional[str]],
) -> WindowsPairingOutcome:
    """Pair with WinRT ProvidePin + authenticated encryption when necessary.

    The PIN exists only in this coroutine and its short-lived event-handler
    closure. It is never attached to a session, exception, log, or preference.
    """
    if any(
        dependency is None
        for dependency in (
            BluetoothLEDevice,
            DeviceInformation,
            DevicePairingKinds,
            DevicePairingProtectionLevel,
            DevicePairingResultStatus,
            assert_mta,
        )
    ):
        raise BlePairingError(
            "Authenticated Bluetooth PIN pairing requires Windows WinRT support"
        )

    await assert_mta()
    native_address = _native_bluetooth_address(address, ble_device)
    requester = None
    custom_pairing = None
    pairing_token = None
    pin: Optional[str] = None
    try:
        requester = await BluetoothLEDevice.from_bluetooth_address_async(
            native_address
        )
        if requester is None:
            raise BlePairingError("Windows could not open the Bluetooth device")
        device_information = await DeviceInformation.create_from_id_async(
            requester.device_information.id
        )
        if device_information is None:
            raise BlePairingError("Windows could not read Bluetooth pairing status")

        pairing = device_information.pairing
        if pairing.is_paired:
            return WindowsPairingOutcome(already_paired=True)
        if not pairing.can_pair:
            raise BlePairingError("Windows reports that this device cannot be paired")

        provided_pin = pin_provider()
        if provided_pin is None:
            raise BlePairingCancelled(PAIRING_CANCELLED_MESSAGE)
        pin = validate_pairing_pin(provided_pin)
        provided_pin = None

        custom_pairing = pairing.custom
        accepted_pin = False

        def pairing_requested(_sender: object, args: object) -> None:
            nonlocal accepted_pin
            if args.pairing_kind == DevicePairingKinds.PROVIDE_PIN:
                args.accept_with_pin(pin)
                accepted_pin = True

        pairing_token = custom_pairing.add_pairing_requested(pairing_requested)
        try:
            async with asyncio.timeout(WINDOWS_PAIRING_TIMEOUT_SECONDS):
                result = await custom_pairing.pair_with_protection_level_async(
                    DevicePairingKinds.PROVIDE_PIN,
                    DevicePairingProtectionLevel.ENCRYPTION_AND_AUTHENTICATION,
                )
        except TimeoutError as exc:
            raise BlePairingError(
                "Windows Bluetooth pairing timed out"
            ) from exc
        except Exception as exc:
            raise BlePairingError(
                "Windows custom Bluetooth pairing failed"
            ) from exc

        successful_statuses = {
            DevicePairingResultStatus.PAIRED,
            DevicePairingResultStatus.ALREADY_PAIRED,
        }
        if result.status not in successful_statuses:
            status_name = getattr(result.status, "name", "UNKNOWN")
            raise BlePairingError(
                f"Windows Bluetooth pairing was not completed ({status_name})"
            )
        if result.status == DevicePairingResultStatus.PAIRED and not accepted_pin:
            raise BlePairingError(
                "Windows completed pairing without requesting the required PIN"
            )
        return WindowsPairingOutcome(
            already_paired=result.status == DevicePairingResultStatus.ALREADY_PAIRED
        )
    finally:
        if custom_pairing is not None and pairing_token is not None:
            try:
                custom_pairing.remove_pairing_requested(pairing_token)
            except Exception:
                pass
        pin = None
        if requester is not None:
            try:
                requester.close()
            except Exception:
                pass


def ble_emitter_from_advertisement(device: object, advertisement: object) -> Optional[BleEmitter]:
    """Convert a Bleak device/advertisement pair into a validated EXOS record."""
    local_name = str(getattr(advertisement, "local_name", "") or "").strip()
    device_name = str(getattr(device, "name", "") or "").strip()
    name = local_name or device_name
    device_id = parse_ble_name(name)
    address = str(getattr(device, "address", "") or "").strip()
    if not device_id or not address:
        return None

    service_uuids = tuple(
        sorted({str(value).lower() for value in getattr(advertisement, "service_uuids", ()) or ()})
    )
    # The name alone is not sufficient: the firmware contract must also expose
    # the Nordic UART service used for NMEA notifications.
    if NUS_SERVICE_UUID not in service_uuids:
        return None

    rssi = getattr(advertisement, "rssi", getattr(device, "rssi", -127))
    try:
        rssi = int(rssi)
    except (TypeError, ValueError):
        rssi = -127
    return BleEmitter(
        device_id,
        name,
        address,
        rssi,
        service_uuids,
        ble_device=device,
    )


def deduplicate_ble_emitters(emitters: Iterable[BleEmitter]) -> list[BleEmitter]:
    """Keep the strongest observation per BLE address, preserving ID collisions."""
    by_address: dict[str, BleEmitter] = {}
    for emitter in emitters:
        key = emitter.address.casefold()
        current = by_address.get(key)
        emitter_rank = (-emitter.rssi, emitter.device_id.upper(), emitter.name)
        current_rank = (
            (-current.rssi, current.device_id.upper(), current.name)
            if current is not None
            else None
        )
        if current is None or emitter_rank < current_rank:
            by_address[key] = emitter
    return sorted(
        by_address.values(),
        key=lambda item: (item.device_id.upper(), item.address.casefold()),
    )


def format_ble_source(emitter: BleEmitter) -> str:
    return (
        f"{BLE_SOURCE_PREFIX}{emitter.address} "
        f"[EXOS-GPS-{emitter.device_id} \u2014 Bluetooth]"
    )


def parse_ble_source(source: object) -> Optional[BleEndpoint]:
    value = str(source or "").strip()
    if not value.lower().startswith(BLE_SOURCE_PREFIX.lower()):
        return None
    remainder = value[len(BLE_SOURCE_PREFIX):]
    if " [" not in remainder or not remainder.endswith("]"):
        raise ValueError("Invalid EXOS BLE source")
    address, bracketed_label = remainder.split(" [", 1)
    label = bracketed_label[:-1]
    label_match = BLE_SOURCE_LABEL_PATTERN.fullmatch(label.strip())
    # Accept the original advertised-name label too, so a selected source from
    # a previous application version continues to connect after an upgrade.
    device_id = (
        label_match.group(1).upper()
        if label_match
        else parse_ble_name(label)
    )
    if not address.strip() or not device_id:
        raise ValueError("Invalid EXOS BLE source")
    return BleEndpoint(address.strip(), device_id)


def ble_available() -> bool:
    return BleakScanner is not None and BleakClient is not None


async def _discover_ble_async(timeout_seconds: float) -> list[BleEmitter]:
    discovered = await BleakScanner.discover(
        timeout=max(0.1, float(timeout_seconds)), return_adv=True
    )
    records: list[BleEmitter] = []
    pairs = discovered.values() if isinstance(discovered, dict) else ()
    for device, advertisement in pairs:
        emitter = ble_emitter_from_advertisement(device, advertisement)
        if emitter is not None:
            records.append(emitter)
    return deduplicate_ble_emitters(records)


def discover_ble_emitters(timeout_seconds: float = 4.0) -> list[BleEmitter]:
    """Perform a bounded BLE scan; call only from a background thread."""
    if not ble_available():
        return []
    return asyncio.run(_discover_ble_async(timeout_seconds))


class NmeaNotificationFramer:
    """Reassemble fragmented BLE notifications into newline-delimited NMEA."""

    def __init__(self, max_buffer: int = 8192, max_sentence_length: int = 512) -> None:
        self._buffer = bytearray()
        self._max_buffer = max(128, int(max_buffer))
        self._max_sentence_length = min(
            max(82, int(max_sentence_length)), self._max_buffer
        )

    @property
    def buffered_bytes(self) -> int:
        """Number of retained bytes, exposed for diagnostics and bound tests."""
        return len(self._buffer)

    def reset(self) -> None:
        self._buffer.clear()

    def feed(self, chunk: bytes) -> list[str]:
        lines: list[str] = []
        # BLE notifications are normally small, so a byte-wise state machine
        # is inexpensive and guarantees the retained buffer never exceeds the
        # configured sentence bound—even for an unterminated stream beginning
        # with '$'. A new '$' always resynchronizes to the newest candidate.
        for value in bytes(chunk):
            if value == ord("$"):
                self._buffer.clear()
                self._buffer.append(value)
                continue
            if not self._buffer:
                continue
            if value == ord("\n"):
                raw = bytes(self._buffer).rstrip(b"\r")
                self._buffer.clear()
                try:
                    line = raw.decode("ascii", errors="strict").strip()
                except UnicodeDecodeError:
                    continue
                if line:
                    lines.append(line)
                continue
            if len(self._buffer) >= self._max_sentence_length:
                # The current sentence is malformed/unterminated. Drop it and
                # ignore bytes until the next '$' marker provides clean resync.
                self._buffer.clear()
                continue
            self._buffer.append(value)
        return lines


class BleNmeaSession:
    """Own a Bleak connection and forward NUS TX notification bytes."""

    def __init__(
        self,
        address: str,
        expected_device_id: str,
        on_data: Callable[[bytes], None],
        on_connected: Callable[[], None],
        on_disconnected: Callable[[str], None],
        on_error: Callable[[str], None],
        connect_timeout: float = 45.0,
        ble_device: object = None,
        expected_canonical_ids: Iterable[str] = (),
        pin_provider: Optional[Callable[[], Optional[str]]] = None,
    ) -> None:
        self.address = address
        self.expected_device_id = expected_device_id.upper()
        self.on_data = on_data
        self.on_connected = on_connected
        self.on_disconnected = on_disconnected
        self.on_error = on_error
        self.connect_timeout = connect_timeout
        self.ble_device = ble_device
        self.pin_provider = pin_provider
        self.pairing_was_existing = False
        canonical_ids: set[str] = set()
        for value in expected_canonical_ids:
            canonical = parse_canonical_identity(value)
            if canonical is None:
                raise ValueError(f"Invalid expected EXOS canonical identity: {value}")
            if short_id_from_canonical(canonical) != self.expected_device_id:
                raise ValueError(
                    f"Canonical identity {canonical} does not match short ID "
                    f"{self.expected_device_id}"
                )
            canonical_ids.add(canonical)
        self.expected_canonical_ids = frozenset(canonical_ids)
        self.canonical_identity: Optional[str] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if not ble_available():
            raise RuntimeError("BLE support is unavailable; install the 'bleak' dependency")
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    @property
    def stop_requested(self) -> bool:
        return self._stop.is_set()

    def _run(self) -> None:
        try:
            asyncio.run(self._run_async())
        except Exception as exc:
            self.on_error(str(exc))

    async def _run_async(self) -> None:
        disconnected = asyncio.Event()

        def disconnected_callback(_client: object) -> None:
            disconnected.set()

        pairing_outcome = await ensure_windows_pin_pairing(
            self.address,
            self.ble_device,
            self.pin_provider or (lambda: None),
        )
        self.pairing_was_existing = pairing_outcome.already_paired

        connected = False
        async with BleakClient(
            self.ble_device or self.address,
            disconnected_callback=disconnected_callback,
            timeout=self.connect_timeout,
            # Pairing has already been completed with WinRT ProvidePin. Bleak's
            # built-in Windows pair=True path only supports ConfirmOnly/Just
            # Works and must not be allowed to downgrade the ceremony.
            pair=False,
            services=[NUS_SERVICE_UUID],
            winrt={"use_cached_services": False},
        ) as client:
            identity_raw = await client.read_gatt_char(NUS_IDENTITY_CHARACTERISTIC_UUID)
            try:
                identity_text = bytes(identity_raw).decode("ascii", errors="strict")
            except UnicodeDecodeError as exc:
                raise RuntimeError("BLE identity is not valid ASCII") from exc
            identity = parse_canonical_identity(identity_text)
            if identity is None:
                raise RuntimeError(
                    "BLE identity is invalid; expected protected EXOS-<12HEX> value"
                )
            derived_short_id = short_id_from_canonical(identity)
            if derived_short_id != self.expected_device_id:
                raise RuntimeError(
                    "BLE advertised identity mismatch: expected short ID "
                    f"{self.expected_device_id}, but {identity} derives "
                    f"{derived_short_id or 'no valid short ID'}"
                )
            if self.expected_canonical_ids and identity not in self.expected_canonical_ids:
                expected = ", ".join(sorted(self.expected_canonical_ids))
                raise RuntimeError(
                    "BLE canonical identity does not match same-ID Wi-Fi discovery: "
                    f"expected {expected}, received {identity}"
                )
            self.canonical_identity = identity
            await client.start_notify(
                NUS_TX_CHARACTERISTIC_UUID,
                lambda _characteristic, data: self.on_data(bytes(data)),
            )
            connected = True
            self.on_connected()
            while not self._stop.is_set() and client.is_connected and not disconnected.is_set():
                await asyncio.sleep(0.1)
            try:
                await client.stop_notify(NUS_TX_CHARACTERISTIC_UUID)
            except Exception:
                pass

        if connected:
            reason = "requested" if self._stop.is_set() else "device disconnected"
            self.on_disconnected(reason)
