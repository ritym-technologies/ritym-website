# EXOS-GPS receiver discovery and connection

The Windows GPS Station receives the same raw NMEA stream over Wi-Fi TCP,
encrypted Bluetooth LE, or USB serial. All verified transports for one device
share a five-character product identity and remain individually selectable.

Install the receiver dependencies once:

```text
python -m pip install -r requirements.txt
```

## Direct connection to the emitter AP

1. Connect Windows to the per-device Wi-Fi network, such as
   `EXOS-GPS-NXKRA`. The final five characters differ on each emitter. The
   development AP password is `exosgps1`.
2. Start the bridge:

   ```text
   python windows_client/gps_receiver.py
   ```

3. Enable **More sources** and choose:

   ```text
   WiFi TCP - 192.168.4.1:2000 [EXOS-GPS AP]
   ```

4. Select **Connect Station**.

## Connection through an existing Wi-Fi network

Connect the emitter and Windows PC to the same network, then start the bridge.
It scans for `_exos-gps._tcp.local.` services in the background. A discovered
unit appears in **GPS Source**, for example:

```text
WiFi TCP - 10.0.0.64:2000 [EXOS-GPS-NXKRA — Wi-Fi]
```

Select it and click **Connect Station**. The app never connects automatically.

The normal source list shows every verified transport. One unit can therefore
appear as Wi-Fi, Bluetooth, and USB at the same time; choose whichever transport
fits the current workflow. Duplicate BLE observations are collapsed by Windows
BLE address, not by the five-character suffix; the address remains visible so
the extremely rare case of two units sharing a suffix is still distinguishable.
Select **More sources** only for the fixed setup AP, legacy
hostname, or an unverified outgoing Bluetooth SPP port. Windows incoming
Bluetooth ports are not valid receiver sources and are always hidden.

Click **Refresh Sources** after changing networks. If DNS-SD discovery is
blocked or unavailable, type the station IP or per-device hostname shown on the
emitter dashboard directly into **GPS Source**:

```text
tcp://192.168.1.123:2000
```

or:

```text
tcp://exos-gps-nxkra.local:2000
```

Replace the example address with the Station IP shown on the dashboard.

## Encrypted Bluetooth LE connection

1. Power the emitter and open its authenticated dashboard. During first setup,
   join `EXOS-GPS-<ID>` with password `exosgps1` and browse to
   `http://192.168.4.1`.
2. Keep the dashboard's six-digit Bluetooth pairing PIN available.
3. Start the Windows receiver and click **Refresh Sources**. A compatible unit
   appears as, for example:

   ```text
   BLE GATT - <Windows BLE address> [EXOS-GPS-NXKRA — Bluetooth]
   ```

4. Select that source and click **Connect Station**. If Windows opens a pairing
   prompt, enter the PIN shown in the dashboard.
5. The app reads the protected full identity in `EXOS-<12HEX>` format, derives
   its five-character hash, and compares that hash with the selected BLE name
   before subscribing to NMEA notifications. If same-suffix Wi-Fi discovery is
   available, the full DNS-SD identity is compared too. A malformed or
   mismatched identity and a rejected PIN are connection failures; GPS data is
   not accepted.
6. Successful GATT authentication first shows **Authenticated — awaiting
   NMEA**. The app changes to **Streaming** only after a structurally valid NMEA
   sentence with a valid checksum arrives. If valid NMEA is silent for 30
   seconds, the BLE bond remains connected but the UI reports **NMEA silent**
   and clears live telemetry instead of continuing to claim it is streaming.

Bluetooth pairing does not require the PC to join the emitter's Wi-Fi network.
Wi-Fi and USB behavior is unchanged, and the user always chooses the transport.

## Expected result

Raw NMEA sentences from the ESP32 appear in the station log and drive its
satellite, position, altitude, speed, bearing, browser bridge, and Windows
sensor integration just like the existing COM input.

If a connection fails, verify that the emitter dashboard reports live GPS NMEA,
that the chosen short ID matches the physical unit, and—when using Wi-Fi—that
the PC can open the dashboard at the corresponding IP address.

DNS-SD discovery normally requires the PC and emitter to be on the same local
subnet. Multicast blocking, client isolation, VPN adapters, and some enterprise
networks can prevent discovery. The fixed AP and manual IP/hostname sources
remain available as fallbacks. `exos-gps-emitter.local` is retained only for
older firmware; current firmware uses a unique hostname such as
`exos-gps-nxkra.local`.
