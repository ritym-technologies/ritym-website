# 🛰️ Exos GPS Solutions

A high-precision GPS telemetry bridge that accepts NMEA 0183 from Android,
EXOS-GPS hardware, or a directly attached GNSS receiver. The Windows receiver
supports Wi-Fi TCP, encrypted Bluetooth LE, USB serial, and legacy Bluetooth
SPP transports.

Desktop version **0.16** uses the paired outgoing EXOS phone port as the
recommended Bluetooth route. The incoming Windows port is an advanced fallback
only. Bluetooth opens run in an isolated helper so a driver timeout can be
cancelled without freezing the desktop app or blocking the next connection.

---

## 📁 Location & Repository Structure

Project Root Path: `D:\Utilities-AI\gps-bridge-gpt`

```
D:\Utilities-AI\gps-bridge-gpt/
├── android/            # Android App (Kotlin + Jetpack Compose + SPP Bluetooth NMEA Service)
├── windows_client/     # Windows Python NMEA Receiver & COM Port Listener
└── README.md           # Master Documentation
```

---

## 📱 1. Android App Setup

The Android app converts your phone's internal high-accuracy GPS into standard **NMEA 0183 sentences** and streams them over a **Bluetooth Classic Serial Port Profile (SPP)** connection (`UUID: 00001101-0000-1000-8000-00805F9B34FB`).

### Key Files:
- [NmeaFormatter.kt](file:///D:/Utilities-AI/gps-bridge-gpt/android/app/src/main/java/com/sostratos/gpsbridge/NmeaFormatter.kt): Converts Android `Location` objects to valid NMEA 0183 strings with checksum calculation.
- [GpsBluetoothService.kt](file:///D:/Utilities-AI/gps-bridge-gpt/android/app/src/main/java/com/sostratos/gpsbridge/GpsBluetoothService.kt): Foreground Service that accepts Bluetooth SPP connections and broadcasts live location.
- [MainActivity.kt](file:///D:/Utilities-AI/gps-bridge-gpt/android/app/src/main/java/com/sostratos/gpsbridge/MainActivity.kt): Jetpack Compose user interface.
- [AndroidManifest.xml](file:///D:/Utilities-AI/gps-bridge-gpt/android/app/src/main/AndroidManifest.xml): App permissions and configuration.

---

## 💻 2. Windows Client Setup

The Windows receiver accepts EXOS GPS data over Wi-Fi, Bluetooth, or USB.
Version 0.13 discovers supported devices automatically and presents them in
plain product language: `Mobile GPS - Bluetooth - Galaxy S24 FE (COM6, Recommended)`,
`Mobile GPS - Bluetooth - Galaxy S24 FE (COM5, Alternative)`,
`Hardware GPS - Wi-Fi - EXOS-GPS-NXKRA`, and
`Hardware GPS - USB - EXOS-GPS-NXKRA`. Bluetooth COM numbers remain visible
for support, while network addresses, protocol names, and baud rates stay hidden.
**Setup options** exposes only the hardware setup network when it is needed.

### Quick Start:
```bash
python -m pip install -r requirements.txt

# Launch Professional GPS Station GUI (Recommended)
python windows_client/gps_receiver.py

# Or launch CLI mode:
python windows_client/gps_receiver.py --cli
```

On this Windows host, you can instead double-click `run_windows_bridge.bat`.
It uses `uv` to create an isolated Python environment with the versions in
`requirements.txt`, including automatic DNS-SD and Bluetooth LE discovery.
Use **Help > About EXOS GPS Station** to view the installed desktop version,
the RiTym Technologies manufacturer information, and **www.ritym.com**.
Click **Rescan Ports**, deliberately select a GPS device, and then click
**Connect Station**. The Connect button remains unavailable until a device is
selected, and stalled Windows Bluetooth COM connections recover after a
15-second timeout instead of remaining on **Connecting** indefinitely. While
Windows is connecting, the button becomes **Cancel Connection** with a visible
countdown; cancelling immediately restores the port picker and rescan control.

For an emitter on the same LAN, click **Rescan Ports** and select its
automatically discovered Wi-Fi entry. For Bluetooth, select the matching
Bluetooth entry; Windows may then ask for the six-digit pairing PIN displayed
in the emitter's authenticated web dashboard. The receiver reads the emitter's
protected canonical identity (`EXOS-<12HEX>`), derives its five-character hash,
and will not accept NMEA unless that hash matches the selected advertisement.
When the same unit was also found over Wi-Fi, its full DNS-SD identity must match
as well.

For first-time or direct setup, connect Windows to the per-device network (for
example `EXOS-GPS-NXKRA`) using `exosgps1`, open `http://192.168.4.1`, and sign
in with the configured dashboard credentials. See `WIFI_GPS.md` for the full
workflow, fallbacks, and troubleshooting.

- Key Files:
  - [gps_station.py](file:///D:/Utilities-AI/gps-bridge-gpt/windows_client/gps_station.py): Professional Desktop GUI Command Center with orbital space animations, satellite signal pulse visualizer, connected device status, and live telemetry cards.
  - [gps_receiver.py](file:///D:/Utilities-AI/gps-bridge-gpt/windows_client/gps_receiver.py): Entry point launcher.

---

## 👤 Developer & Copyright Details
- **Company**: RiTym Technologies
- **Website**: [RiTym.com](https://www.ritym.com/)
- **Product**: Exos GPS Solutions
- **Copyright**: © 2026 RiTym Technologies. All rights reserved.
